var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "  218,424",
        "ok": "  218,155",
        "ko": "      269"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   35,118",
        "ok": "   35,118",
        "ko": "    6,619"
    },
    "meanResponseTime": {
        "total": "    4,390",
        "ok": "    4,395",
        "ko": "      422"
    },
    "standardDeviation": {
        "total": "    3,266",
        "ok": "    3,265",
        "ko": "      620"
    },
    "percentiles1": {
        "total": "    3,407",
        "ok": "    3,410",
        "ko": "      228"
    },
    "percentiles2": {
        "total": "    5,534",
        "ok": "    5,538",
        "ko": "      513"
    },
    "percentiles3": {
        "total": "   11,116",
        "ok": "   11,134",
        "ko": "    1,439"
    },
    "percentiles4": {
        "total": "   16,170",
        "ok": "   16,206",
        "ko": "    2,195"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 4890,
    "percentage": 2.238764970882321
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 10041,
    "percentage": 4.5970223052411825
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 203224,
    "percentage": 93.0410577592206
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 269,
    "percentage": 0.12315496465589862
},
    "meanNumberOfRequestsPerSecond": {
        "total": "    79.51",
        "ok": "    79.42",
        "ko": "      0.1"
    }
},
contents: {
"req_go-to-login-pag-1537763987": {
        type: "REQUEST",
        name: "Go to login page",
path: "Go to login page",
pathFormatted: "req_go-to-login-pag-1537763987",
stats: {
    "name": "Go to login page",
    "numberOfRequests": {
        "total": "      892",
        "ok": "      892",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "       10",
        "ok": "       10",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "        1",
        "ok": "        1",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "        6",
        "ok": "        6",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 892,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.32",
        "ok": "     0.32",
        "ko": "        -"
    }
}
    },"req_submit-credenti--2043499788": {
        type: "REQUEST",
        name: "submit credentials",
path: "submit credentials",
pathFormatted: "req_submit-credenti--2043499788",
stats: {
    "name": "submit credentials",
    "numberOfRequests": {
        "total": "      892",
        "ok": "      891",
        "ko": "        1"
    },
    "minResponseTime": {
        "total": "      263",
        "ok": "      263",
        "ko": "      441"
    },
    "maxResponseTime": {
        "total": "   18,513",
        "ok": "   18,513",
        "ko": "      441"
    },
    "meanResponseTime": {
        "total": "    2,435",
        "ok": "    2,438",
        "ko": "      441"
    },
    "standardDeviation": {
        "total": "    2,655",
        "ok": "    2,655",
        "ko": "        0"
    },
    "percentiles1": {
        "total": "    1,438",
        "ok": "    1,441",
        "ko": "      441"
    },
    "percentiles2": {
        "total": "    3,026",
        "ok": "    3,031",
        "ko": "      441"
    },
    "percentiles3": {
        "total": "    8,571",
        "ok": "    8,572",
        "ko": "      441"
    },
    "percentiles4": {
        "total": "   12,363",
        "ok": "   12,364",
        "ko": "      441"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 285,
    "percentage": 31.950672645739907
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 115,
    "percentage": 12.892376681614351
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 491,
    "percentage": 55.044843049327355
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.11210762331838565
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.32",
        "ok": "     0.32",
        "ko": "        0"
    }
}
    },"req_check-user-logg-946489478": {
        type: "REQUEST",
        name: "check user logged in",
path: "check user logged in",
pathFormatted: "req_check-user-logg-946489478",
stats: {
    "name": "check user logged in",
    "numberOfRequests": {
        "total": "      891",
        "ok": "      891",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "      461",
        "ok": "      461",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   20,345",
        "ok": "   20,345",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    3,230",
        "ok": "    3,230",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    2,989",
        "ok": "    2,989",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    2,305",
        "ok": "    2,306",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    4,018",
        "ok": "    4,019",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   10,097",
        "ok": "   10,097",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   14,129",
        "ok": "   14,129",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 112,
    "percentage": 12.570145903479238
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 129,
    "percentage": 14.47811447811448
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 650,
    "percentage": 72.9517396184063
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.32",
        "ok": "     0.32",
        "ko": "        -"
    }
}
    },"req_go-to-user-prog--2104020333": {
        type: "REQUEST",
        name: "Go to user program page",
path: "Go to user program page",
pathFormatted: "req_go-to-user-prog--2104020333",
stats: {
    "name": "Go to user program page",
    "numberOfRequests": {
        "total": "      891",
        "ok": "      891",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "    1,340",
        "ok": "    1,340",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   35,118",
        "ok": "   35,118",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    7,006",
        "ok": "    7,006",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    4,426",
        "ok": "    4,426",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    5,986",
        "ok": "    5,986",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    8,433",
        "ok": "    8,433",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   16,140",
        "ok": "   16,140",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   23,861",
        "ok": "   23,861",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 891,
    "percentage": 100.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.32",
        "ok": "     0.32",
        "ko": "        -"
    }
}
    },"req_go-to-breakout---1000037037": {
        type: "REQUEST",
        name: "Go to breakout page",
path: "Go to breakout page",
pathFormatted: "req_go-to-breakout---1000037037",
stats: {
    "name": "Go to breakout page",
    "numberOfRequests": {
        "total": "   10,346",
        "ok": "   10,345",
        "ko": "        1"
    },
    "minResponseTime": {
        "total": "      883",
        "ok": "      883",
        "ko": "    6,619"
    },
    "maxResponseTime": {
        "total": "   30,860",
        "ok": "   30,860",
        "ko": "    6,619"
    },
    "meanResponseTime": {
        "total": "    5,042",
        "ok": "    5,042",
        "ko": "    6,619"
    },
    "standardDeviation": {
        "total": "    3,679",
        "ok": "    3,680",
        "ko": "        0"
    },
    "percentiles1": {
        "total": "    4,003",
        "ok": "    4,003",
        "ko": "    6,619"
    },
    "percentiles2": {
        "total": "    6,277",
        "ok": "    6,276",
        "ko": "    6,619"
    },
    "percentiles3": {
        "total": "   12,862",
        "ok": "   12,863",
        "ko": "    6,619"
    },
    "percentiles4": {
        "total": "   18,056",
        "ok": "   18,056",
        "ko": "    6,619"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 89,
    "percentage": 0.8602358399381403
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10256,
    "percentage": 99.1300985888266
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.009665571235260004
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.77",
        "ok": "     3.77",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768716124": {
        type: "REQUEST",
        name: "Accept vote (citation # 1)",
path: "Accept vote (citation # 1)",
pathFormatted: "req_accept-vote--ci--768716124",
stats: {
    "name": "Accept vote (citation # 1)",
    "numberOfRequests": {
        "total": "   10,345",
        "ok": "   10,333",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       66",
        "ok": "      495",
        "ko": "       66"
    },
    "maxResponseTime": {
        "total": "   24,778",
        "ok": "   24,778",
        "ko": "    1,129"
    },
    "meanResponseTime": {
        "total": "    4,439",
        "ok": "    4,444",
        "ko": "      326"
    },
    "standardDeviation": {
        "total": "    3,042",
        "ok": "    3,040",
        "ko": "      334"
    },
    "percentiles1": {
        "total": "    3,447",
        "ok": "    3,451",
        "ko": "      185"
    },
    "percentiles2": {
        "total": "    5,500",
        "ok": "    5,503",
        "ko": "      397"
    },
    "percentiles3": {
        "total": "   10,833",
        "ok": "   10,836",
        "ko": "    1,129"
    },
    "percentiles4": {
        "total": "   14,962",
        "ok": "   14,965",
        "ko": "    1,129"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 28,
    "percentage": 0.2706621556307395
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 203,
    "percentage": 1.9623006283228612
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10102,
    "percentage": 97.65103914934751
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.11599806669888835
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.77",
        "ok": "     3.76",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826041": {
        type: "REQUEST",
        name: "Cancel vote (citation 1)",
path: "Cancel vote (citation 1)",
pathFormatted: "req_cancel-vote--ci-1326826041",
stats: {
    "name": "Cancel vote (citation 1)",
    "numberOfRequests": {
        "total": "   10,333",
        "ok": "   10,321",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       20",
        "ok": "      494",
        "ko": "       20"
    },
    "maxResponseTime": {
        "total": "   26,880",
        "ok": "   26,880",
        "ko": "      759"
    },
    "meanResponseTime": {
        "total": "    4,596",
        "ok": "    4,601",
        "ko": "      283"
    },
    "standardDeviation": {
        "total": "    3,124",
        "ok": "    3,123",
        "ko": "      213"
    },
    "percentiles1": {
        "total": "    3,572",
        "ok": "    3,575",
        "ko": "      223"
    },
    "percentiles2": {
        "total": "    5,682",
        "ok": "    5,686",
        "ko": "      524"
    },
    "percentiles3": {
        "total": "   11,056",
        "ok": "   11,059",
        "ko": "      759"
    },
    "percentiles4": {
        "total": "   15,745",
        "ok": "   15,749",
        "ko": "      759"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 18,
    "percentage": 0.1741991677150876
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 167,
    "percentage": 1.6161811671344235
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10136,
    "percentage": 98.09348688667376
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.11613277847672505
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.76",
        "ok": "     3.76",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768716093": {
        type: "REQUEST",
        name: "Accept vote (citation # 2)",
path: "Accept vote (citation # 2)",
pathFormatted: "req_accept-vote--ci--768716093",
stats: {
    "name": "Accept vote (citation # 2)",
    "numberOfRequests": {
        "total": "   10,321",
        "ok": "   10,304",
        "ko": "       17"
    },
    "minResponseTime": {
        "total": "       29",
        "ok": "      550",
        "ko": "       29"
    },
    "maxResponseTime": {
        "total": "   28,083",
        "ok": "   28,083",
        "ko": "    1,839"
    },
    "meanResponseTime": {
        "total": "    4,527",
        "ok": "    4,533",
        "ko": "      468"
    },
    "standardDeviation": {
        "total": "    3,048",
        "ok": "    3,046",
        "ko": "      506"
    },
    "percentiles1": {
        "total": "    3,548",
        "ok": "    3,553",
        "ko": "      268"
    },
    "percentiles2": {
        "total": "    5,584",
        "ok": "    5,589",
        "ko": "      583"
    },
    "percentiles3": {
        "total": "   10,876",
        "ok": "   10,880",
        "ko": "    1,839"
    },
    "percentiles4": {
        "total": "   15,340",
        "ok": "   15,347",
        "ko": "    1,839"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.13564577075864742
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 163,
    "percentage": 1.5793043309756807
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10127,
    "percentage": 98.12033717663017
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17,
    "percentage": 0.16471272163550044
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.76",
        "ok": "     3.75",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826072": {
        type: "REQUEST",
        name: "Cancel vote (citation 2)",
path: "Cancel vote (citation 2)",
pathFormatted: "req_cancel-vote--ci-1326826072",
stats: {
    "name": "Cancel vote (citation 2)",
    "numberOfRequests": {
        "total": "   10,304",
        "ok": "   10,291",
        "ko": "       13"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      658",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   28,032",
        "ok": "   28,032",
        "ko": "    1,514"
    },
    "meanResponseTime": {
        "total": "    4,630",
        "ok": "    4,636",
        "ko": "      333"
    },
    "standardDeviation": {
        "total": "    3,184",
        "ok": "    3,183",
        "ko": "      386"
    },
    "percentiles1": {
        "total": "    3,603",
        "ok": "    3,606",
        "ko": "      177"
    },
    "percentiles2": {
        "total": "    5,694",
        "ok": "    5,698",
        "ko": "      477"
    },
    "percentiles3": {
        "total": "   11,206",
        "ok": "   11,209",
        "ko": "    1,514"
    },
    "percentiles4": {
        "total": "   16,790",
        "ok": "   16,794",
        "ko": "    1,514"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 13,
    "percentage": 0.12616459627329193
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 144,
    "percentage": 1.3975155279503106
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10134,
    "percentage": 98.3501552795031
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0.12616459627329193
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.75",
        "ok": "     3.75",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155049977": {
        type: "REQUEST",
        name: "Reject vote (citation # 3)",
path: "Reject vote (citation # 3)",
pathFormatted: "req_reject-vote--ci-155049977",
stats: {
    "name": "Reject vote (citation # 3)",
    "numberOfRequests": {
        "total": "   10,291",
        "ok": "   10,280",
        "ko": "       11"
    },
    "minResponseTime": {
        "total": "       73",
        "ok": "      515",
        "ko": "       73"
    },
    "maxResponseTime": {
        "total": "   23,397",
        "ok": "   23,397",
        "ko": "      935"
    },
    "meanResponseTime": {
        "total": "    3,551",
        "ok": "    3,554",
        "ko": "      423"
    },
    "standardDeviation": {
        "total": "    3,191",
        "ok": "    3,191",
        "ko": "      306"
    },
    "percentiles1": {
        "total": "    2,538",
        "ok": "    2,542",
        "ko": "      227"
    },
    "percentiles2": {
        "total": "    4,463",
        "ok": "    4,466",
        "ko": "      805"
    },
    "percentiles3": {
        "total": "   10,410",
        "ok": "   10,419",
        "ko": "      935"
    },
    "percentiles4": {
        "total": "   15,083",
        "ok": "   15,078",
        "ko": "      935"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 728,
    "percentage": 7.074142454571956
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1546,
    "percentage": 15.022835487319016
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8006,
    "percentage": 77.79613254299875
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0.10688951511029054
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.75",
        "ok": "     3.74",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200556": {
        type: "REQUEST",
        name: "Rejection reason (citation 3)",
path: "Rejection reason (citation 3)",
pathFormatted: "req_rejection-reaso-933200556",
stats: {
    "name": "Rejection reason (citation 3)",
    "numberOfRequests": {
        "total": "   10,280",
        "ok": "   10,274",
        "ko": "        6"
    },
    "minResponseTime": {
        "total": "       90",
        "ok": "      394",
        "ko": "       90"
    },
    "maxResponseTime": {
        "total": "   23,384",
        "ok": "   23,384",
        "ko": "      536"
    },
    "meanResponseTime": {
        "total": "    3,997",
        "ok": "    3,999",
        "ko": "      341"
    },
    "standardDeviation": {
        "total": "    2,956",
        "ok": "    2,956",
        "ko": "      156"
    },
    "percentiles1": {
        "total": "    3,004",
        "ok": "    3,005",
        "ko": "      360"
    },
    "percentiles2": {
        "total": "    4,998",
        "ok": "    5,000",
        "ko": "      515"
    },
    "percentiles3": {
        "total": "   10,151",
        "ok": "   10,152",
        "ko": "      536"
    },
    "percentiles4": {
        "total": "   14,475",
        "ok": "   14,477",
        "ko": "      536"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 114,
    "percentage": 1.1089494163424125
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 549,
    "percentage": 5.340466926070039
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9611,
    "percentage": 93.49221789883269
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0.058365758754863814
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.74",
        "ok": "     3.74",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826103": {
        type: "REQUEST",
        name: "Cancel vote (citation 3)",
path: "Cancel vote (citation 3)",
pathFormatted: "req_cancel-vote--ci-1326826103",
stats: {
    "name": "Cancel vote (citation 3)",
    "numberOfRequests": {
        "total": "   10,274",
        "ok": "   10,259",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      537",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   27,931",
        "ok": "   27,931",
        "ko": "    2,195"
    },
    "meanResponseTime": {
        "total": "    4,701",
        "ok": "    4,707",
        "ko": "      490"
    },
    "standardDeviation": {
        "total": "    3,237",
        "ok": "    3,235",
        "ko": "      622"
    },
    "percentiles1": {
        "total": "    3,672",
        "ok": "    3,677",
        "ko": "      238"
    },
    "percentiles2": {
        "total": "    5,796",
        "ok": "    5,801",
        "ko": "      509"
    },
    "percentiles3": {
        "total": "   11,341",
        "ok": "   11,346",
        "ko": "    2,195"
    },
    "percentiles4": {
        "total": "   16,778",
        "ok": "   16,783",
        "ko": "    2,195"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.1362663032898579
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 119,
    "percentage": 1.1582635779637922
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10126,
    "percentage": 98.55947050807865
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.14599961066770487
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.74",
        "ok": "     3.73",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050008": {
        type: "REQUEST",
        name: "Reject vote (citation # 4)",
path: "Reject vote (citation # 4)",
pathFormatted: "req_reject-vote--ci-155050008",
stats: {
    "name": "Reject vote (citation # 4)",
    "numberOfRequests": {
        "total": "   10,259",
        "ok": "   10,249",
        "ko": "       10"
    },
    "minResponseTime": {
        "total": "       34",
        "ok": "      513",
        "ko": "       34"
    },
    "maxResponseTime": {
        "total": "   23,122",
        "ok": "   23,122",
        "ko": "    4,738"
    },
    "meanResponseTime": {
        "total": "    3,545",
        "ok": "    3,548",
        "ko": "      729"
    },
    "standardDeviation": {
        "total": "    3,187",
        "ok": "    3,188",
        "ko": "    1,358"
    },
    "percentiles1": {
        "total": "    2,491",
        "ok": "    2,493",
        "ko": "      327"
    },
    "percentiles2": {
        "total": "    4,477",
        "ok": "    4,479",
        "ko": "      536"
    },
    "percentiles3": {
        "total": "   10,349",
        "ok": "   10,353",
        "ko": "    4,738"
    },
    "percentiles4": {
        "total": "   15,138",
        "ok": "   15,114",
        "ko": "    4,738"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 720,
    "percentage": 7.018227897455892
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1551,
    "percentage": 15.118432595769567
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7978,
    "percentage": 77.76586411930987
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 10,
    "percentage": 0.09747538746466518
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.73",
        "ok": "     3.73",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200587": {
        type: "REQUEST",
        name: "Rejection reason (citation 4)",
path: "Rejection reason (citation 4)",
pathFormatted: "req_rejection-reaso-933200587",
stats: {
    "name": "Rejection reason (citation 4)",
    "numberOfRequests": {
        "total": "   10,249",
        "ok": "   10,236",
        "ko": "       13"
    },
    "minResponseTime": {
        "total": "       15",
        "ok": "      373",
        "ko": "       15"
    },
    "maxResponseTime": {
        "total": "   23,123",
        "ok": "   23,123",
        "ko": "      740"
    },
    "meanResponseTime": {
        "total": "    3,936",
        "ok": "    3,941",
        "ko": "      326"
    },
    "standardDeviation": {
        "total": "    2,921",
        "ok": "    2,920",
        "ko": "      264"
    },
    "percentiles1": {
        "total": "    2,935",
        "ok": "    2,938",
        "ko": "      223"
    },
    "percentiles2": {
        "total": "    4,901",
        "ok": "    4,903",
        "ko": "      569"
    },
    "percentiles3": {
        "total": "   10,102",
        "ok": "   10,105",
        "ko": "      740"
    },
    "percentiles4": {
        "total": "   14,340",
        "ok": "   14,344",
        "ko": "      740"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 138,
    "percentage": 1.346472826617231
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 501,
    "percentage": 4.888281783588642
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9597,
    "percentage": 93.638403746707
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0.12684164308713045
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.73",
        "ok": "     3.73",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826134": {
        type: "REQUEST",
        name: "Cancel vote (citation 4)",
path: "Cancel vote (citation 4)",
pathFormatted: "req_cancel-vote--ci-1326826134",
stats: {
    "name": "Cancel vote (citation 4)",
    "numberOfRequests": {
        "total": "   10,236",
        "ok": "   10,220",
        "ko": "       16"
    },
    "minResponseTime": {
        "total": "       12",
        "ok": "      558",
        "ko": "       12"
    },
    "maxResponseTime": {
        "total": "   29,067",
        "ok": "   29,067",
        "ko": "    1,771"
    },
    "meanResponseTime": {
        "total": "    4,824",
        "ok": "    4,831",
        "ko": "      430"
    },
    "standardDeviation": {
        "total": "    3,332",
        "ok": "    3,330",
        "ko": "      488"
    },
    "percentiles1": {
        "total": "    3,748",
        "ok": "    3,752",
        "ko": "      284"
    },
    "percentiles2": {
        "total": "    5,879",
        "ok": "    5,883",
        "ko": "      440"
    },
    "percentiles3": {
        "total": "   11,638",
        "ok": "   11,641",
        "ko": "    1,771"
    },
    "percentiles4": {
        "total": "   17,047",
        "ok": "   17,050",
        "ko": "    1,771"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0.07815552950371239
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 94,
    "percentage": 0.9183274716686205
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10118,
    "percentage": 98.84720593982024
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16,
    "percentage": 0.15631105900742479
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.73",
        "ok": "     3.72",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716000": {
        type: "REQUEST",
        name: "Accept vote (citation # 5)",
path: "Accept vote (citation # 5)",
pathFormatted: "req_accept-vote--ci--768716000",
stats: {
    "name": "Accept vote (citation # 5)",
    "numberOfRequests": {
        "total": "   10,220",
        "ok": "   10,204",
        "ko": "       16"
    },
    "minResponseTime": {
        "total": "       10",
        "ok": "      590",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   26,150",
        "ok": "   26,150",
        "ko": "      930"
    },
    "meanResponseTime": {
        "total": "    4,828",
        "ok": "    4,835",
        "ko": "      249"
    },
    "standardDeviation": {
        "total": "    3,227",
        "ok": "    3,225",
        "ko": "      243"
    },
    "percentiles1": {
        "total": "    3,801",
        "ok": "    3,806",
        "ko": "      197"
    },
    "percentiles2": {
        "total": "    5,983",
        "ok": "    5,988",
        "ko": "      355"
    },
    "percentiles3": {
        "total": "   11,596",
        "ok": "   11,600",
        "ko": "      930"
    },
    "percentiles4": {
        "total": "   16,185",
        "ok": "   16,192",
        "ko": "      930"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7,
    "percentage": 0.0684931506849315
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 84,
    "percentage": 0.821917808219178
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10113,
    "percentage": 98.95303326810176
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16,
    "percentage": 0.15655577299412915
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.72",
        "ok": "     3.71",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826165": {
        type: "REQUEST",
        name: "Cancel vote (citation 5)",
path: "Cancel vote (citation 5)",
pathFormatted: "req_cancel-vote--ci-1326826165",
stats: {
    "name": "Cancel vote (citation 5)",
    "numberOfRequests": {
        "total": "   10,204",
        "ok": "   10,194",
        "ko": "       10"
    },
    "minResponseTime": {
        "total": "       11",
        "ok": "      667",
        "ko": "       11"
    },
    "maxResponseTime": {
        "total": "   28,779",
        "ok": "   28,779",
        "ko": "      497"
    },
    "meanResponseTime": {
        "total": "    4,909",
        "ok": "    4,914",
        "ko": "      175"
    },
    "standardDeviation": {
        "total": "    3,278",
        "ok": "    3,276",
        "ko": "      177"
    },
    "percentiles1": {
        "total": "    3,868",
        "ok": "    3,871",
        "ko": "      102"
    },
    "percentiles2": {
        "total": "    6,026",
        "ok": "    6,029",
        "ko": "      343"
    },
    "percentiles3": {
        "total": "   11,514",
        "ok": "   11,516",
        "ko": "      497"
    },
    "percentiles4": {
        "total": "   16,911",
        "ok": "   16,915",
        "ko": "      497"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 9,
    "percentage": 0.08820070560564484
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 81,
    "percentage": 0.7938063504508036
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10104,
    "percentage": 99.01999215993727
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 10,
    "percentage": 0.09800078400627205
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.71",
        "ok": "     3.71",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768715969": {
        type: "REQUEST",
        name: "Accept vote (citation # 6)",
path: "Accept vote (citation # 6)",
pathFormatted: "req_accept-vote--ci--768715969",
stats: {
    "name": "Accept vote (citation # 6)",
    "numberOfRequests": {
        "total": "   10,194",
        "ok": "   10,184",
        "ko": "       10"
    },
    "minResponseTime": {
        "total": "      102",
        "ok": "      603",
        "ko": "      102"
    },
    "maxResponseTime": {
        "total": "   24,299",
        "ok": "   24,299",
        "ko": "    1,069"
    },
    "meanResponseTime": {
        "total": "    4,917",
        "ok": "    4,922",
        "ko": "      474"
    },
    "standardDeviation": {
        "total": "    3,195",
        "ok": "    3,194",
        "ko": "      305"
    },
    "percentiles1": {
        "total": "    3,898",
        "ok": "    3,901",
        "ko": "      502"
    },
    "percentiles2": {
        "total": "    6,097",
        "ok": "    6,099",
        "ko": "      563"
    },
    "percentiles3": {
        "total": "   11,510",
        "ok": "   11,513",
        "ko": "    1,069"
    },
    "percentiles4": {
        "total": "   16,054",
        "ok": "   16,056",
        "ko": "    1,069"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 4,
    "percentage": 0.039238767902687856
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 68,
    "percentage": 0.6670590543456936
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10112,
    "percentage": 99.1956052579949
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 10,
    "percentage": 0.09809691975671965
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.71",
        "ok": "     3.71",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826196": {
        type: "REQUEST",
        name: "Cancel vote (citation 6)",
path: "Cancel vote (citation 6)",
pathFormatted: "req_cancel-vote--ci-1326826196",
stats: {
    "name": "Cancel vote (citation 6)",
    "numberOfRequests": {
        "total": "   10,184",
        "ok": "   10,164",
        "ko": "       20"
    },
    "minResponseTime": {
        "total": "       18",
        "ok": "      618",
        "ko": "       18"
    },
    "maxResponseTime": {
        "total": "   27,711",
        "ok": "   27,711",
        "ko": "      912"
    },
    "meanResponseTime": {
        "total": "    5,048",
        "ok": "    5,057",
        "ko": "      239"
    },
    "standardDeviation": {
        "total": "    3,360",
        "ok": "    3,357",
        "ko": "      187"
    },
    "percentiles1": {
        "total": "    3,998",
        "ok": "    4,004",
        "ko": "      225"
    },
    "percentiles2": {
        "total": "    6,177",
        "ok": "    6,183",
        "ko": "      297"
    },
    "percentiles3": {
        "total": "   11,831",
        "ok": "   11,836",
        "ko": "      912"
    },
    "percentiles4": {
        "total": "   17,429",
        "ok": "   17,436",
        "ko": "      912"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0.07855459544383347
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 63,
    "percentage": 0.6186174391201885
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10093,
    "percentage": 99.10644147682639
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0.19638648860958366
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.71",
        "ok": "      3.7",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050101": {
        type: "REQUEST",
        name: "Reject vote (citation # 7)",
path: "Reject vote (citation # 7)",
pathFormatted: "req_reject-vote--ci-155050101",
stats: {
    "name": "Reject vote (citation # 7)",
    "numberOfRequests": {
        "total": "   10,164",
        "ok": "   10,158",
        "ko": "        6"
    },
    "minResponseTime": {
        "total": "      154",
        "ok": "      507",
        "ko": "      154"
    },
    "maxResponseTime": {
        "total": "   26,849",
        "ok": "   26,849",
        "ko": "    1,482"
    },
    "meanResponseTime": {
        "total": "    3,529",
        "ok": "    3,530",
        "ko": "      516"
    },
    "standardDeviation": {
        "total": "    3,180",
        "ok": "    3,180",
        "ko": "      444"
    },
    "percentiles1": {
        "total": "    2,484",
        "ok": "    2,486",
        "ko": "      405"
    },
    "percentiles2": {
        "total": "    4,490",
        "ok": "    4,490",
        "ko": "      432"
    },
    "percentiles3": {
        "total": "   10,363",
        "ok": "   10,367",
        "ko": "    1,482"
    },
    "percentiles4": {
        "total": "   15,038",
        "ok": "   15,043",
        "ko": "    1,482"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 748,
    "percentage": 7.35930735930736
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1547,
    "percentage": 15.22038567493113
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7863,
    "percentage": 77.36127508854781
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0.05903187721369539
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.7",
        "ok": "      3.7",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200680": {
        type: "REQUEST",
        name: "Rejection reason (citation 7)",
path: "Rejection reason (citation 7)",
pathFormatted: "req_rejection-reaso-933200680",
stats: {
    "name": "Rejection reason (citation 7)",
    "numberOfRequests": {
        "total": "   10,158",
        "ok": "   10,146",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       13",
        "ok": "      355",
        "ko": "       13"
    },
    "maxResponseTime": {
        "total": "   23,193",
        "ok": "   23,193",
        "ko": "    1,832"
    },
    "meanResponseTime": {
        "total": "    3,908",
        "ok": "    3,912",
        "ko": "      507"
    },
    "standardDeviation": {
        "total": "    2,893",
        "ok": "    2,892",
        "ko": "      522"
    },
    "percentiles1": {
        "total": "    2,936",
        "ok": "    2,939",
        "ko": "      431"
    },
    "percentiles2": {
        "total": "    4,881",
        "ok": "    4,885",
        "ko": "      786"
    },
    "percentiles3": {
        "total": "    9,989",
        "ok": "    9,992",
        "ko": "    1,832"
    },
    "percentiles4": {
        "total": "   14,542",
        "ok": "   14,545",
        "ko": "    1,832"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 134,
    "percentage": 1.3191573144319748
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 542,
    "percentage": 5.335696003150226
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9470,
    "percentage": 93.22701319157315
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.11813349084465447
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.7",
        "ok": "     3.69",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826227": {
        type: "REQUEST",
        name: "Cancel vote (citation 7)",
path: "Cancel vote (citation 7)",
pathFormatted: "req_cancel-vote--ci-1326826227",
stats: {
    "name": "Cancel vote (citation 7)",
    "numberOfRequests": {
        "total": "   10,146",
        "ok": "   10,136",
        "ko": "       10"
    },
    "minResponseTime": {
        "total": "       30",
        "ok": "      646",
        "ko": "       30"
    },
    "maxResponseTime": {
        "total": "   29,180",
        "ok": "   29,180",
        "ko": "    1,181"
    },
    "meanResponseTime": {
        "total": "    5,090",
        "ok": "    5,094",
        "ko": "      422"
    },
    "standardDeviation": {
        "total": "    3,469",
        "ok": "    3,468",
        "ko": "      322"
    },
    "percentiles1": {
        "total": "    3,994",
        "ok": "    3,997",
        "ko": "      396"
    },
    "percentiles2": {
        "total": "    6,200",
        "ok": "    6,203",
        "ko": "      579"
    },
    "percentiles3": {
        "total": "   12,093",
        "ok": "   12,096",
        "ko": "    1,181"
    },
    "percentiles4": {
        "total": "   18,225",
        "ok": "   18,229",
        "ko": "    1,181"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 0.029568302779420463
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 60,
    "percentage": 0.5913660555884093
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10073,
    "percentage": 99.28050463236744
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 10,
    "percentage": 0.09856100926473486
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.69",
        "ok": "     3.69",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155050132": {
        type: "REQUEST",
        name: "Reject vote (citation # 8)",
path: "Reject vote (citation # 8)",
pathFormatted: "req_reject-vote--ci-155050132",
stats: {
    "name": "Reject vote (citation # 8)",
    "numberOfRequests": {
        "total": "   10,136",
        "ok": "   10,116",
        "ko": "       20"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      493",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   23,930",
        "ok": "   23,930",
        "ko": "    1,758"
    },
    "meanResponseTime": {
        "total": "    3,489",
        "ok": "    3,495",
        "ko": "      387"
    },
    "standardDeviation": {
        "total": "    3,136",
        "ok": "    3,136",
        "ko": "      458"
    },
    "percentiles1": {
        "total": "    2,489",
        "ok": "    2,495",
        "ko": "      191"
    },
    "percentiles2": {
        "total": "    4,482",
        "ok": "    4,488",
        "ko": "      511"
    },
    "percentiles3": {
        "total": "   10,008",
        "ok": "   10,014",
        "ko": "    1,758"
    },
    "percentiles4": {
        "total": "   14,835",
        "ok": "   14,838",
        "ko": "    1,758"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 743,
    "percentage": 7.330307813733228
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1591,
    "percentage": 15.696527229676402
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7782,
    "percentage": 76.77584846093133
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0.1973164956590371
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.69",
        "ok": "     3.68",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200711": {
        type: "REQUEST",
        name: "Rejection reason (citation 8)",
path: "Rejection reason (citation 8)",
pathFormatted: "req_rejection-reaso-933200711",
stats: {
    "name": "Rejection reason (citation 8)",
    "numberOfRequests": {
        "total": "   10,116",
        "ok": "   10,098",
        "ko": "       18"
    },
    "minResponseTime": {
        "total": "       54",
        "ok": "      340",
        "ko": "       54"
    },
    "maxResponseTime": {
        "total": "   22,411",
        "ok": "   22,411",
        "ko": "    1,505"
    },
    "meanResponseTime": {
        "total": "    3,916",
        "ok": "    3,922",
        "ko": "      549"
    },
    "standardDeviation": {
        "total": "    2,930",
        "ok": "    2,929",
        "ko": "      435"
    },
    "percentiles1": {
        "total": "    2,880",
        "ok": "    2,884",
        "ko": "      475"
    },
    "percentiles2": {
        "total": "    4,930",
        "ok": "    4,936",
        "ko": "      831"
    },
    "percentiles3": {
        "total": "   10,096",
        "ok": "   10,100",
        "ko": "    1,505"
    },
    "percentiles4": {
        "total": "   14,024",
        "ok": "   14,032",
        "ko": "    1,505"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 145,
    "percentage": 1.4333728746540133
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 579,
    "percentage": 5.723606168446026
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9374,
    "percentage": 92.66508501383946
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 18,
    "percentage": 0.1779359430604982
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.68",
        "ok": "     3.68",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826258": {
        type: "REQUEST",
        name: "Cancel vote (citation 8)",
path: "Cancel vote (citation 8)",
pathFormatted: "req_cancel-vote--ci-1326826258",
stats: {
    "name": "Cancel vote (citation 8)",
    "numberOfRequests": {
        "total": "   10,098",
        "ok": "   10,078",
        "ko": "       20"
    },
    "minResponseTime": {
        "total": "       14",
        "ok": "      639",
        "ko": "       14"
    },
    "maxResponseTime": {
        "total": "   29,040",
        "ok": "   29,040",
        "ko": "    2,058"
    },
    "meanResponseTime": {
        "total": "    5,200",
        "ok": "    5,210",
        "ko": "      404"
    },
    "standardDeviation": {
        "total": "    3,489",
        "ok": "    3,485",
        "ko": "      585"
    },
    "percentiles1": {
        "total": "    4,086",
        "ok": "    4,092",
        "ko": "      219"
    },
    "percentiles2": {
        "total": "    6,300",
        "ok": "    6,305",
        "ko": "      502"
    },
    "percentiles3": {
        "total": "   12,383",
        "ok": "   12,388",
        "ko": "    2,058"
    },
    "percentiles4": {
        "total": "   18,256",
        "ok": "   18,260",
        "ko": "    2,058"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5,
    "percentage": 0.04951475539710833
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 56,
    "percentage": 0.5545652604476135
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10017,
    "percentage": 99.19786096256684
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0.19805902158843333
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.68",
        "ok": "     3.67",
        "ko": "     0.01"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
