var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "  190,240",
        "ok": "  189,463",
        "ko": "      777"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   60,001",
        "ok": "   59,208",
        "ko": "   60,001"
    },
    "meanResponseTime": {
        "total": "    5,333",
        "ok": "    5,341",
        "ko": "    3,487"
    },
    "standardDeviation": {
        "total": "    5,266",
        "ok": "    5,251",
        "ko": "    7,982"
    },
    "percentiles1": {
        "total": "    3,160",
        "ok": "    3,169",
        "ko": "    1,566"
    },
    "percentiles2": {
        "total": "    7,176",
        "ok": "    7,193",
        "ko": "    2,706"
    },
    "percentiles3": {
        "total": "   16,921",
        "ok": "   16,955",
        "ko": "   12,875"
    },
    "percentiles4": {
        "total": "   23,414",
        "ok": "   23,556",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7904,
    "percentage": 4.15475189234651
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 12604,
    "percentage": 6.6253153910849445
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 168955,
    "percentage": 88.81150126156435
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 777,
    "percentage": 0.4084314550042052
},
    "meanNumberOfRequestsPerSecond": {
        "total": "    65.53",
        "ok": "    65.26",
        "ko": "     0.27"
    }
},
contents: {
"req_go-to-login-pag-1537763987": {
        type: "REQUEST",
        name: "Go to login page",
path: "Go to login page",
pathFormatted: "req_go-to-login-pag-1537763987",
stats: {
    "name": "Go to login page",
    "numberOfRequests": {
        "total": "    1,247",
        "ok": "    1,247",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "       14",
        "ok": "       14",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "        1",
        "ok": "        1",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "        6",
        "ok": "        6",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "       10",
        "ok": "       10",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1247,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.43",
        "ok": "     0.43",
        "ko": "        -"
    }
}
    },"req_submit-credenti--2043499788": {
        type: "REQUEST",
        name: "submit credentials",
path: "submit credentials",
pathFormatted: "req_submit-credenti--2043499788",
stats: {
    "name": "submit credentials",
    "numberOfRequests": {
        "total": "    1,247",
        "ok": "    1,155",
        "ko": "       92"
    },
    "minResponseTime": {
        "total": "      282",
        "ok": "      282",
        "ko": "      525"
    },
    "maxResponseTime": {
        "total": "   32,509",
        "ok": "   32,509",
        "ko": "   15,010"
    },
    "meanResponseTime": {
        "total": "    3,454",
        "ok": "    3,498",
        "ko": "    2,899"
    },
    "standardDeviation": {
        "total": "    4,226",
        "ok": "    4,324",
        "ko": "    2,658"
    },
    "percentiles1": {
        "total": "    1,800",
        "ok": "    1,831",
        "ko": "    1,676"
    },
    "percentiles2": {
        "total": "    4,460",
        "ok": "    4,616",
        "ko": "    2,730"
    },
    "percentiles3": {
        "total": "   12,316",
        "ok": "   12,498",
        "ko": "    7,174"
    },
    "percentiles4": {
        "total": "   19,863",
        "ok": "   19,928",
        "ko": "   15,010"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 352,
    "percentage": 28.22774659182037
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 123,
    "percentage": 9.863672814755413
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 680,
    "percentage": 54.530874097834804
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 92,
    "percentage": 7.377706495589415
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.43",
        "ok": "      0.4",
        "ko": "     0.03"
    }
}
    },"req_check-user-logg-946489478": {
        type: "REQUEST",
        name: "check user logged in",
path: "check user logged in",
pathFormatted: "req_check-user-logg-946489478",
stats: {
    "name": "check user logged in",
    "numberOfRequests": {
        "total": "    1,155",
        "ok": "    1,108",
        "ko": "       47"
    },
    "minResponseTime": {
        "total": "      486",
        "ok": "      486",
        "ko": "    1,529"
    },
    "maxResponseTime": {
        "total": "   43,703",
        "ok": "   43,703",
        "ko": "   10,398"
    },
    "meanResponseTime": {
        "total": "    4,497",
        "ok": "    4,574",
        "ko": "    2,670"
    },
    "standardDeviation": {
        "total": "    5,260",
        "ok": "    5,346",
        "ko": "    1,660"
    },
    "percentiles1": {
        "total": "    2,450",
        "ok": "    2,482",
        "ko": "    1,822"
    },
    "percentiles2": {
        "total": "    5,462",
        "ok": "    5,646",
        "ko": "    3,250"
    },
    "percentiles3": {
        "total": "   16,517",
        "ok": "   16,769",
        "ko": "    5,666"
    },
    "percentiles4": {
        "total": "   24,134",
        "ok": "   24,595",
        "ko": "   10,398"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 116,
    "percentage": 10.043290043290042
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 150,
    "percentage": 12.987012987012985
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 842,
    "percentage": 72.9004329004329
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 47,
    "percentage": 4.069264069264069
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      0.4",
        "ok": "     0.38",
        "ko": "     0.02"
    }
}
    },"req_go-to-user-prog--2104020333": {
        type: "REQUEST",
        name: "Go to user program page",
path: "Go to user program page",
pathFormatted: "req_go-to-user-prog--2104020333",
stats: {
    "name": "Go to user program page",
    "numberOfRequests": {
        "total": "    1,108",
        "ok": "    1,062",
        "ko": "       46"
    },
    "minResponseTime": {
        "total": "    1,440",
        "ok": "    1,440",
        "ko": "    1,526"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   53,211",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    8,896",
        "ok": "    9,097",
        "ko": "    4,256"
    },
    "standardDeviation": {
        "total": "    6,948",
        "ok": "    6,794",
        "ko": "    8,634"
    },
    "percentiles1": {
        "total": "    6,723",
        "ok": "    7,007",
        "ko": "    2,102"
    },
    "percentiles2": {
        "total": "   11,484",
        "ok": "   11,846",
        "ko": "    4,308"
    },
    "percentiles3": {
        "total": "   21,742",
        "ok": "   21,907",
        "ko": "    6,598"
    },
    "percentiles4": {
        "total": "   34,616",
        "ok": "   33,757",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1062,
    "percentage": 95.84837545126354
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 46,
    "percentage": 4.1516245487364625
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.38",
        "ok": "     0.37",
        "ko": "     0.02"
    }
}
    },"req_go-to-breakout---1000037037": {
        type: "REQUEST",
        name: "Go to breakout page",
path: "Go to breakout page",
pathFormatted: "req_go-to-breakout---1000037037",
stats: {
    "name": "Go to breakout page",
    "numberOfRequests": {
        "total": "    9,130",
        "ok": "    9,099",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "      842",
        "ok": "      842",
        "ko": "    1,534"
    },
    "maxResponseTime": {
        "total": "   60,001",
        "ok": "   49,172",
        "ko": "   60,001"
    },
    "meanResponseTime": {
        "total": "    6,328",
        "ok": "    6,328",
        "ko": "    6,321"
    },
    "standardDeviation": {
        "total": "    6,021",
        "ok": "    5,975",
        "ko": "   14,188"
    },
    "percentiles1": {
        "total": "    3,888",
        "ok": "    3,895",
        "ko": "    1,585"
    },
    "percentiles2": {
        "total": "    8,773",
        "ok": "    8,795",
        "ko": "    3,956"
    },
    "percentiles3": {
        "total": "   19,339",
        "ok": "   19,331",
        "ko": "   60,001"
    },
    "percentiles4": {
        "total": "   26,517",
        "ok": "   26,465",
        "ko": "   60,001"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 307,
    "percentage": 3.3625410733844467
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8792,
    "percentage": 96.29791894852136
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.33953997809419495
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.15",
        "ok": "     3.13",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716124": {
        type: "REQUEST",
        name: "Accept vote (citation # 1)",
path: "Accept vote (citation # 1)",
pathFormatted: "req_accept-vote--ci--768716124",
stats: {
    "name": "Accept vote (citation # 1)",
    "numberOfRequests": {
        "total": "    9,099",
        "ok": "    9,061",
        "ko": "       38"
    },
    "minResponseTime": {
        "total": "       42",
        "ok": "      480",
        "ko": "       42"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   55,721",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,469",
        "ok": "    5,471",
        "ko": "    4,862"
    },
    "standardDeviation": {
        "total": "    5,158",
        "ok": "    5,127",
        "ko": "   10,130"
    },
    "percentiles1": {
        "total": "    3,272",
        "ok": "    3,278",
        "ko": "    1,560"
    },
    "percentiles2": {
        "total": "    7,362",
        "ok": "    7,369",
        "ko": "    6,770"
    },
    "percentiles3": {
        "total": "   16,658",
        "ok": "   16,682",
        "ko": "   15,239"
    },
    "percentiles4": {
        "total": "   23,317",
        "ok": "   23,290",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 69,
    "percentage": 0.7583250906693043
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 364,
    "percentage": 4.000439608748215
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8628,
    "percentage": 94.8236069897791
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 38,
    "percentage": 0.417628310803385
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.13",
        "ok": "     3.12",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826041": {
        type: "REQUEST",
        name: "Cancel vote (citation 1)",
path: "Cancel vote (citation 1)",
pathFormatted: "req_cancel-vote--ci-1326826041",
stats: {
    "name": "Cancel vote (citation 1)",
    "numberOfRequests": {
        "total": "    9,061",
        "ok": "    9,029",
        "ko": "       32"
    },
    "minResponseTime": {
        "total": "       35",
        "ok": "      510",
        "ko": "       35"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   57,293",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,651",
        "ok": "    5,653",
        "ko": "    5,153"
    },
    "standardDeviation": {
        "total": "    5,245",
        "ok": "    5,185",
        "ko": "   14,257"
    },
    "percentiles1": {
        "total": "    3,367",
        "ok": "    3,376",
        "ko": "    1,552"
    },
    "percentiles2": {
        "total": "    7,634",
        "ok": "    7,652",
        "ko": "    2,073"
    },
    "percentiles3": {
        "total": "   17,282",
        "ok": "   17,277",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   23,161",
        "ok": "   23,118",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 43,
    "percentage": 0.47456130669903984
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 300,
    "percentage": 3.3108928374351616
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8686,
    "percentage": 95.86138395320604
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 32,
    "percentage": 0.35316190265975056
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.12",
        "ok": "     3.11",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716093": {
        type: "REQUEST",
        name: "Accept vote (citation # 2)",
path: "Accept vote (citation # 2)",
pathFormatted: "req_accept-vote--ci--768716093",
stats: {
    "name": "Accept vote (citation # 2)",
    "numberOfRequests": {
        "total": "    9,029",
        "ok": "    8,995",
        "ko": "       34"
    },
    "minResponseTime": {
        "total": "       30",
        "ok": "      509",
        "ko": "       30"
    },
    "maxResponseTime": {
        "total": "   58,573",
        "ok": "   58,573",
        "ko": "   13,125"
    },
    "meanResponseTime": {
        "total": "    5,490",
        "ok": "    5,503",
        "ko": "    2,255"
    },
    "standardDeviation": {
        "total": "    5,027",
        "ok": "    5,029",
        "ko": "    2,853"
    },
    "percentiles1": {
        "total": "    3,327",
        "ok": "    3,334",
        "ko": "    1,561"
    },
    "percentiles2": {
        "total": "    7,337",
        "ok": "    7,359",
        "ko": "    2,008"
    },
    "percentiles3": {
        "total": "   16,251",
        "ok": "   16,275",
        "ko": "    8,033"
    },
    "percentiles4": {
        "total": "   22,860",
        "ok": "   22,810",
        "ko": "   13,125"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 49,
    "percentage": 0.5426957581127478
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 334,
    "percentage": 3.699191494074648
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8612,
    "percentage": 95.38154834422417
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 34,
    "percentage": 0.37656440358843724
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.11",
        "ok": "      3.1",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826072": {
        type: "REQUEST",
        name: "Cancel vote (citation 2)",
path: "Cancel vote (citation 2)",
pathFormatted: "req_cancel-vote--ci-1326826072",
stats: {
    "name": "Cancel vote (citation 2)",
    "numberOfRequests": {
        "total": "    8,995",
        "ok": "    8,976",
        "ko": "       19"
    },
    "minResponseTime": {
        "total": "       21",
        "ok": "      595",
        "ko": "       21"
    },
    "maxResponseTime": {
        "total": "   46,140",
        "ok": "   46,140",
        "ko": "    8,033"
    },
    "meanResponseTime": {
        "total": "    5,620",
        "ok": "    5,628",
        "ko": "    2,061"
    },
    "standardDeviation": {
        "total": "    5,134",
        "ok": "    5,136",
        "ko": "    2,540"
    },
    "percentiles1": {
        "total": "    3,422",
        "ok": "    3,427",
        "ko": "    1,152"
    },
    "percentiles2": {
        "total": "    7,469",
        "ok": "    7,479",
        "ko": "    2,177"
    },
    "percentiles3": {
        "total": "   16,963",
        "ok": "   16,977",
        "ko": "    8,033"
    },
    "percentiles4": {
        "total": "   23,410",
        "ok": "   23,412",
        "ko": "    8,033"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 39,
    "percentage": 0.43357420789327406
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 222,
    "percentage": 2.4680377987770985
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8715,
    "percentage": 96.88715953307393
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19,
    "percentage": 0.2112284602556976
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.1",
        "ok": "     3.09",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155049977": {
        type: "REQUEST",
        name: "Reject vote (citation # 3)",
path: "Reject vote (citation # 3)",
pathFormatted: "req_reject-vote--ci-155049977",
stats: {
    "name": "Reject vote (citation # 3)",
    "numberOfRequests": {
        "total": "    8,976",
        "ok": "    8,944",
        "ko": "       32"
    },
    "minResponseTime": {
        "total": "       28",
        "ok": "      461",
        "ko": "       28"
    },
    "maxResponseTime": {
        "total": "   51,092",
        "ok": "   51,092",
        "ko": "    8,654"
    },
    "meanResponseTime": {
        "total": "    4,516",
        "ok": "    4,527",
        "ko": "    1,369"
    },
    "standardDeviation": {
        "total": "    5,148",
        "ok": "    5,153",
        "ko": "    1,521"
    },
    "percentiles1": {
        "total": "    2,205",
        "ok": "    2,218",
        "ko": "    1,530"
    },
    "percentiles2": {
        "total": "    6,264",
        "ok": "    6,288",
        "ko": "    1,609"
    },
    "percentiles3": {
        "total": "   16,357",
        "ok": "   16,377",
        "ko": "    2,806"
    },
    "percentiles4": {
        "total": "   22,727",
        "ok": "   22,691",
        "ko": "    8,654"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1110,
    "percentage": 12.366310160427807
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1658,
    "percentage": 18.471479500891267
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6176,
    "percentage": 68.80570409982175
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 32,
    "percentage": 0.35650623885918004
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.09",
        "ok": "     3.08",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200556": {
        type: "REQUEST",
        name: "Rejection reason (citation 3)",
path: "Rejection reason (citation 3)",
pathFormatted: "req_rejection-reaso-933200556",
stats: {
    "name": "Rejection reason (citation 3)",
    "numberOfRequests": {
        "total": "    8,944",
        "ok": "    8,914",
        "ko": "       30"
    },
    "minResponseTime": {
        "total": "       32",
        "ok": "      288",
        "ko": "       32"
    },
    "maxResponseTime": {
        "total": "   56,007",
        "ok": "   56,007",
        "ko": "    6,980"
    },
    "meanResponseTime": {
        "total": "    4,730",
        "ok": "    4,741",
        "ko": "    1,372"
    },
    "standardDeviation": {
        "total": "    4,727",
        "ok": "    4,729",
        "ko": "    1,802"
    },
    "percentiles1": {
        "total": "    2,666",
        "ok": "    2,673",
        "ko": "      739"
    },
    "percentiles2": {
        "total": "    6,147",
        "ok": "    6,164",
        "ko": "    1,565"
    },
    "percentiles3": {
        "total": "   15,309",
        "ok": "   15,334",
        "ko": "    6,294"
    },
    "percentiles4": {
        "total": "   21,645",
        "ok": "   21,654",
        "ko": "    6,980"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 299,
    "percentage": 3.343023255813953
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 718,
    "percentage": 8.02772808586762
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7897,
    "percentage": 88.2938282647585
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 30,
    "percentage": 0.3354203935599284
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.08",
        "ok": "     3.07",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826103": {
        type: "REQUEST",
        name: "Cancel vote (citation 3)",
path: "Cancel vote (citation 3)",
pathFormatted: "req_cancel-vote--ci-1326826103",
stats: {
    "name": "Cancel vote (citation 3)",
    "numberOfRequests": {
        "total": "    8,914",
        "ok": "    8,892",
        "ko": "       22"
    },
    "minResponseTime": {
        "total": "       95",
        "ok": "      595",
        "ko": "       95"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   56,748",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,773",
        "ok": "    5,774",
        "ko": "    5,328"
    },
    "standardDeviation": {
        "total": "    5,348",
        "ok": "    5,318",
        "ko": "   12,593"
    },
    "percentiles1": {
        "total": "    3,473",
        "ok": "    3,477",
        "ko": "      635"
    },
    "percentiles2": {
        "total": "    7,719",
        "ok": "    7,727",
        "ko": "    5,566"
    },
    "percentiles3": {
        "total": "   17,975",
        "ok": "   17,976",
        "ko": "   14,937"
    },
    "percentiles4": {
        "total": "   24,049",
        "ok": "   24,036",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 36,
    "percentage": 0.4038590980480144
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 259,
    "percentage": 2.905541844289881
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8597,
    "percentage": 96.44379627552165
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22,
    "percentage": 0.24680278214045323
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.07",
        "ok": "     3.06",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050008": {
        type: "REQUEST",
        name: "Reject vote (citation # 4)",
path: "Reject vote (citation # 4)",
pathFormatted: "req_reject-vote--ci-155050008",
stats: {
    "name": "Reject vote (citation # 4)",
    "numberOfRequests": {
        "total": "    8,892",
        "ok": "    8,865",
        "ko": "       27"
    },
    "minResponseTime": {
        "total": "       32",
        "ok": "      459",
        "ko": "       32"
    },
    "maxResponseTime": {
        "total": "   60,001",
        "ok": "   50,947",
        "ko": "   60,001"
    },
    "meanResponseTime": {
        "total": "    4,503",
        "ok": "    4,503",
        "ko": "    4,247"
    },
    "standardDeviation": {
        "total": "    5,234",
        "ok": "    5,206",
        "ko": "   11,141"
    },
    "percentiles1": {
        "total": "    2,149",
        "ok": "    2,154",
        "ko": "    1,535"
    },
    "percentiles2": {
        "total": "    6,274",
        "ok": "    6,285",
        "ko": "    3,817"
    },
    "percentiles3": {
        "total": "   16,154",
        "ok": "   16,158",
        "ko": "    7,178"
    },
    "percentiles4": {
        "total": "   22,793",
        "ok": "   22,777",
        "ko": "   60,001"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1212,
    "percentage": 13.630229419703104
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1607,
    "percentage": 18.07242465137202
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6046,
    "percentage": 67.99370220422853
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27,
    "percentage": 0.30364372469635625
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.06",
        "ok": "     3.05",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200587": {
        type: "REQUEST",
        name: "Rejection reason (citation 4)",
path: "Rejection reason (citation 4)",
pathFormatted: "req_rejection-reaso-933200587",
stats: {
    "name": "Rejection reason (citation 4)",
    "numberOfRequests": {
        "total": "    8,865",
        "ok": "    8,832",
        "ko": "       33"
    },
    "minResponseTime": {
        "total": "       61",
        "ok": "      346",
        "ko": "       61"
    },
    "maxResponseTime": {
        "total": "   58,054",
        "ok": "   58,054",
        "ko": "   15,119"
    },
    "meanResponseTime": {
        "total": "    4,831",
        "ok": "    4,837",
        "ko": "    3,195"
    },
    "standardDeviation": {
        "total": "    4,826",
        "ok": "    4,828",
        "ko": "    3,971"
    },
    "percentiles1": {
        "total": "    2,682",
        "ok": "    2,686",
        "ko": "    1,534"
    },
    "percentiles2": {
        "total": "    6,433",
        "ok": "    6,431",
        "ko": "    4,533"
    },
    "percentiles3": {
        "total": "   15,751",
        "ok": "   15,753",
        "ko": "   14,634"
    },
    "percentiles4": {
        "total": "   21,671",
        "ok": "   21,682",
        "ko": "   15,119"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 300,
    "percentage": 3.3840947546531304
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 688,
    "percentage": 7.760857304004512
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7844,
    "percentage": 88.48279751833051
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 33,
    "percentage": 0.3722504230118443
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.05",
        "ok": "     3.04",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826134": {
        type: "REQUEST",
        name: "Cancel vote (citation 4)",
path: "Cancel vote (citation 4)",
pathFormatted: "req_cancel-vote--ci-1326826134",
stats: {
    "name": "Cancel vote (citation 4)",
    "numberOfRequests": {
        "total": "    8,832",
        "ok": "    8,799",
        "ko": "       33"
    },
    "minResponseTime": {
        "total": "       40",
        "ok": "      518",
        "ko": "       40"
    },
    "maxResponseTime": {
        "total": "   58,339",
        "ok": "   58,339",
        "ko": "   15,320"
    },
    "meanResponseTime": {
        "total": "    5,800",
        "ok": "    5,810",
        "ko": "    3,042"
    },
    "standardDeviation": {
        "total": "    5,307",
        "ok": "    5,308",
        "ko": "    4,157"
    },
    "percentiles1": {
        "total": "    3,482",
        "ok": "    3,489",
        "ko": "    1,547"
    },
    "percentiles2": {
        "total": "    7,762",
        "ok": "    7,778",
        "ko": "    1,586"
    },
    "percentiles3": {
        "total": "   17,746",
        "ok": "   17,769",
        "ko": "   14,908"
    },
    "percentiles4": {
        "total": "   24,223",
        "ok": "   24,235",
        "ko": "   15,320"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 28,
    "percentage": 0.3170289855072464
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 231,
    "percentage": 2.6154891304347827
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8540,
    "percentage": 96.69384057971014
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 33,
    "percentage": 0.3736413043478261
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.04",
        "ok": "     3.03",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716000": {
        type: "REQUEST",
        name: "Accept vote (citation # 5)",
path: "Accept vote (citation # 5)",
pathFormatted: "req_accept-vote--ci--768716000",
stats: {
    "name": "Accept vote (citation # 5)",
    "numberOfRequests": {
        "total": "    8,799",
        "ok": "    8,771",
        "ko": "       28"
    },
    "minResponseTime": {
        "total": "       17",
        "ok": "      575",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   56,661",
        "ok": "   56,661",
        "ko": "   14,351"
    },
    "meanResponseTime": {
        "total": "    5,758",
        "ok": "    5,770",
        "ko": "    2,185"
    },
    "standardDeviation": {
        "total": "    5,272",
        "ok": "    5,274",
        "ko": "    3,001"
    },
    "percentiles1": {
        "total": "    3,543",
        "ok": "    3,550",
        "ko": "    1,399"
    },
    "percentiles2": {
        "total": "    7,607",
        "ok": "    7,627",
        "ko": "    1,970"
    },
    "percentiles3": {
        "total": "   17,346",
        "ok": "   17,368",
        "ko": "    7,401"
    },
    "percentiles4": {
        "total": "   24,582",
        "ok": "   24,599",
        "ko": "   14,351"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.15910898965791567
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 208,
    "percentage": 2.3639049892033186
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8549,
    "percentage": 97.15876804182292
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 28,
    "percentage": 0.31821797931583135
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.03",
        "ok": "     3.02",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826165": {
        type: "REQUEST",
        name: "Cancel vote (citation 5)",
path: "Cancel vote (citation 5)",
pathFormatted: "req_cancel-vote--ci-1326826165",
stats: {
    "name": "Cancel vote (citation 5)",
    "numberOfRequests": {
        "total": "    8,771",
        "ok": "    8,740",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "       68",
        "ok": "      683",
        "ko": "       68"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   45,400",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,913",
        "ok": "    5,917",
        "ko": "    4,770"
    },
    "standardDeviation": {
        "total": "    5,314",
        "ok": "    5,286",
        "ko": "   10,606"
    },
    "percentiles1": {
        "total": "    3,631",
        "ok": "    3,636",
        "ko": "    1,585"
    },
    "percentiles2": {
        "total": "    7,944",
        "ok": "    7,961",
        "ko": "    5,561"
    },
    "percentiles3": {
        "total": "   17,919",
        "ok": "   17,928",
        "ko": "   15,102"
    },
    "percentiles4": {
        "total": "   24,157",
        "ok": "   24,141",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.1596169193934557
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 195,
    "percentage": 2.223235662980276
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8531,
    "percentage": 97.26370995325505
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.35343746437122336
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.02",
        "ok": "     3.01",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768715969": {
        type: "REQUEST",
        name: "Accept vote (citation # 6)",
path: "Accept vote (citation # 6)",
pathFormatted: "req_accept-vote--ci--768715969",
stats: {
    "name": "Accept vote (citation # 6)",
    "numberOfRequests": {
        "total": "    8,740",
        "ok": "    8,709",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "       58",
        "ok": "      687",
        "ko": "       58"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   55,803",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,927",
        "ok": "    5,930",
        "ko": "    5,058"
    },
    "standardDeviation": {
        "total": "    5,452",
        "ok": "    5,422",
        "ko": "   10,975"
    },
    "percentiles1": {
        "total": "    3,615",
        "ok": "    3,620",
        "ko": "    1,540"
    },
    "percentiles2": {
        "total": "    7,760",
        "ok": "    7,770",
        "ko": "    6,509"
    },
    "percentiles3": {
        "total": "   18,136",
        "ok": "   18,144",
        "ko": "   15,183"
    },
    "percentiles4": {
        "total": "   25,140",
        "ok": "   25,118",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16,
    "percentage": 0.1830663615560641
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 172,
    "percentage": 1.9679633867276887
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8521,
    "percentage": 97.49427917620137
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.35469107551487417
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.01",
        "ok": "        3",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826196": {
        type: "REQUEST",
        name: "Cancel vote (citation 6)",
path: "Cancel vote (citation 6)",
pathFormatted: "req_cancel-vote--ci-1326826196",
stats: {
    "name": "Cancel vote (citation 6)",
    "numberOfRequests": {
        "total": "    8,709",
        "ok": "    8,685",
        "ko": "       24"
    },
    "minResponseTime": {
        "total": "       17",
        "ok": "      681",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   59,156",
        "ok": "   59,156",
        "ko": "   15,647"
    },
    "meanResponseTime": {
        "total": "    5,943",
        "ok": "    5,950",
        "ko": "    3,374"
    },
    "standardDeviation": {
        "total": "    5,357",
        "ok": "    5,356",
        "ko": "    4,973"
    },
    "percentiles1": {
        "total": "    3,648",
        "ok": "    3,655",
        "ko": "    1,558"
    },
    "percentiles2": {
        "total": "    7,902",
        "ok": "    7,910",
        "ko": "    3,374"
    },
    "percentiles3": {
        "total": "   17,756",
        "ok": "   17,773",
        "ko": "   15,006"
    },
    "percentiles4": {
        "total": "   23,979",
        "ok": "   24,035",
        "ko": "   15,647"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 13,
    "percentage": 0.14927086921575383
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 143,
    "percentage": 1.641979561373292
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8529,
    "percentage": 97.93317258008956
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 24,
    "percentage": 0.2755769893213917
},
    "meanNumberOfRequestsPerSecond": {
        "total": "        3",
        "ok": "     2.99",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050101": {
        type: "REQUEST",
        name: "Reject vote (citation # 7)",
path: "Reject vote (citation # 7)",
pathFormatted: "req_reject-vote--ci-155050101",
stats: {
    "name": "Reject vote (citation # 7)",
    "numberOfRequests": {
        "total": "    8,685",
        "ok": "    8,665",
        "ko": "       20"
    },
    "minResponseTime": {
        "total": "      117",
        "ok": "      449",
        "ko": "      117"
    },
    "maxResponseTime": {
        "total": "   57,664",
        "ok": "   57,664",
        "ko": "   15,195"
    },
    "meanResponseTime": {
        "total": "    4,354",
        "ok": "    4,356",
        "ko": "    3,299"
    },
    "standardDeviation": {
        "total": "    5,053",
        "ok": "    5,055",
        "ko": "    3,612"
    },
    "percentiles1": {
        "total": "    2,066",
        "ok": "    2,069",
        "ko": "    1,636"
    },
    "percentiles2": {
        "total": "    6,027",
        "ok": "    6,027",
        "ko": "    6,203"
    },
    "percentiles3": {
        "total": "   15,943",
        "ok": "   15,908",
        "ko": "   15,195"
    },
    "percentiles4": {
        "total": "   22,343",
        "ok": "   22,230",
        "ko": "   15,195"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1164,
    "percentage": 13.402417962003454
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1663,
    "percentage": 19.147956246401844
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 5838,
    "percentage": 67.21934369602764
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0.2302820955670697
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.99",
        "ok": "     2.98",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200680": {
        type: "REQUEST",
        name: "Rejection reason (citation 7)",
path: "Rejection reason (citation 7)",
pathFormatted: "req_rejection-reaso-933200680",
stats: {
    "name": "Rejection reason (citation 7)",
    "numberOfRequests": {
        "total": "    8,665",
        "ok": "    8,634",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "       27",
        "ok": "      326",
        "ko": "       27"
    },
    "maxResponseTime": {
        "total": "   54,873",
        "ok": "   54,873",
        "ko": "   13,765"
    },
    "meanResponseTime": {
        "total": "    4,728",
        "ok": "    4,739",
        "ko": "    1,775"
    },
    "standardDeviation": {
        "total": "    4,803",
        "ok": "    4,806",
        "ko": "    2,459"
    },
    "percentiles1": {
        "total": "    2,605",
        "ok": "    2,610",
        "ko": "    1,540"
    },
    "percentiles2": {
        "total": "    6,126",
        "ok": "    6,145",
        "ko": "    1,657"
    },
    "percentiles3": {
        "total": "   15,493",
        "ok": "   15,533",
        "ko": "    5,489"
    },
    "percentiles4": {
        "total": "   21,762",
        "ok": "   21,790",
        "ko": "   13,765"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 302,
    "percentage": 3.485285631852279
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 692,
    "percentage": 7.986151182919793
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7640,
    "percentage": 88.17080207732256
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.3577611079053664
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.98",
        "ok": "     2.97",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826227": {
        type: "REQUEST",
        name: "Cancel vote (citation 7)",
path: "Cancel vote (citation 7)",
pathFormatted: "req_cancel-vote--ci-1326826227",
stats: {
    "name": "Cancel vote (citation 7)",
    "numberOfRequests": {
        "total": "    8,634",
        "ok": "    8,607",
        "ko": "       27"
    },
    "minResponseTime": {
        "total": "       46",
        "ok": "      627",
        "ko": "       46"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   47,110",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,027",
        "ok": "    6,033",
        "ko": "    3,992"
    },
    "standardDeviation": {
        "total": "    5,433",
        "ok": "    5,404",
        "ko": "   11,125"
    },
    "percentiles1": {
        "total": "    3,707",
        "ok": "    3,714",
        "ko": "    1,585"
    },
    "percentiles2": {
        "total": "    8,028",
        "ok": "    8,049",
        "ko": "    2,444"
    },
    "percentiles3": {
        "total": "   17,821",
        "ok": "   17,824",
        "ko": "    7,584"
    },
    "percentiles4": {
        "total": "   24,948",
        "ok": "   24,870",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 10,
    "percentage": 0.11582117211026176
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 155,
    "percentage": 1.7952281677090571
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8442,
    "percentage": 97.77623349548298
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27,
    "percentage": 0.3127171646977068
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.97",
        "ok": "     2.96",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050132": {
        type: "REQUEST",
        name: "Reject vote (citation # 8)",
path: "Reject vote (citation # 8)",
pathFormatted: "req_reject-vote--ci-155050132",
stats: {
    "name": "Reject vote (citation # 8)",
    "numberOfRequests": {
        "total": "    8,607",
        "ok": "    8,579",
        "ko": "       28"
    },
    "minResponseTime": {
        "total": "       59",
        "ok": "      477",
        "ko": "       59"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   37,501",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    4,421",
        "ok": "    4,420",
        "ko": "    4,490"
    },
    "standardDeviation": {
        "total": "    5,102",
        "ok": "    5,070",
        "ko": "   11,303"
    },
    "percentiles1": {
        "total": "    2,066",
        "ok": "    2,073",
        "ko": "    1,555"
    },
    "percentiles2": {
        "total": "    6,143",
        "ok": "    6,153",
        "ko": "    2,070"
    },
    "percentiles3": {
        "total": "   16,038",
        "ok": "   16,044",
        "ko": "   15,668"
    },
    "percentiles4": {
        "total": "   22,159",
        "ok": "   22,073",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1168,
    "percentage": 13.570349715347973
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1639,
    "percentage": 19.04263971186244
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 5772,
    "percentage": 67.0616939700244
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 28,
    "percentage": 0.32531660276519114
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.96",
        "ok": "     2.96",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200711": {
        type: "REQUEST",
        name: "Rejection reason (citation 8)",
path: "Rejection reason (citation 8)",
pathFormatted: "req_rejection-reaso-933200711",
stats: {
    "name": "Rejection reason (citation 8)",
    "numberOfRequests": {
        "total": "    8,579",
        "ok": "    8,557",
        "ko": "       22"
    },
    "minResponseTime": {
        "total": "       62",
        "ok": "      333",
        "ko": "       62"
    },
    "maxResponseTime": {
        "total": "   59,208",
        "ok": "   59,208",
        "ko": "    7,050"
    },
    "meanResponseTime": {
        "total": "    4,735",
        "ok": "    4,742",
        "ko": "    2,114"
    },
    "standardDeviation": {
        "total": "    4,848",
        "ok": "    4,851",
        "ko": "    2,010"
    },
    "percentiles1": {
        "total": "    2,563",
        "ok": "    2,566",
        "ko": "    1,559"
    },
    "percentiles2": {
        "total": "    6,239",
        "ok": "    6,253",
        "ko": "    2,512"
    },
    "percentiles3": {
        "total": "   15,690",
        "ok": "   15,707",
        "ko": "    6,903"
    },
    "percentiles4": {
        "total": "   21,709",
        "ok": "   21,718",
        "ko": "    7,050"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 296,
    "percentage": 3.450285581070055
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 669,
    "percentage": 7.798111668026577
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7592,
    "percentage": 88.49516260636437
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22,
    "percentage": 0.25644014453899056
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.96",
        "ok": "     2.95",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826258": {
        type: "REQUEST",
        name: "Cancel vote (citation 8)",
path: "Cancel vote (citation 8)",
pathFormatted: "req_cancel-vote--ci-1326826258",
stats: {
    "name": "Cancel vote (citation 8)",
    "numberOfRequests": {
        "total": "    8,557",
        "ok": "    8,538",
        "ko": "       19"
    },
    "minResponseTime": {
        "total": "      128",
        "ok": "      658",
        "ko": "      128"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   54,688",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,124",
        "ok": "    6,128",
        "ko": "    4,714"
    },
    "standardDeviation": {
        "total": "    5,468",
        "ok": "    5,438",
        "ko": "   13,148"
    },
    "percentiles1": {
        "total": "    3,789",
        "ok": "    3,795",
        "ko": "    1,532"
    },
    "percentiles2": {
        "total": "    8,034",
        "ok": "    8,048",
        "ko": "    1,611"
    },
    "percentiles3": {
        "total": "   18,287",
        "ok": "   18,286",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   24,943",
        "ok": "   24,965",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 7,
    "percentage": 0.08180437069066263
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 107,
    "percentage": 1.2504382377001286
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8424,
    "percentage": 98.4457169568774
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19,
    "percentage": 0.22204043473179852
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.95",
        "ok": "     2.94",
        "ko": "     0.01"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
