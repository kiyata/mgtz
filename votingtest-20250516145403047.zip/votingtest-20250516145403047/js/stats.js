var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "  221,540",
        "ok": "  220,573",
        "ko": "      967"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        9"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   34,062",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    4,400",
        "ok": "    4,409",
        "ko": "    2,375"
    },
    "standardDeviation": {
        "total": "    2,799",
        "ok": "    2,786",
        "ko": "    4,580"
    },
    "percentiles1": {
        "total": "    3,892",
        "ok": "    3,903",
        "ko": "    1,553"
    },
    "percentiles2": {
        "total": "    5,808",
        "ok": "    5,815",
        "ko": "    2,542"
    },
    "percentiles3": {
        "total": "    9,611",
        "ok": "    9,642",
        "ko": "    6,864"
    },
    "percentiles4": {
        "total": "   13,570",
        "ok": "   13,647",
        "ko": "    9,533"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 6008,
    "percentage": 2.7119256116276973
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 9522,
    "percentage": 4.298095152116999
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 205043,
    "percentage": 92.55348921188047
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 967,
    "percentage": 0.43649002437483075
},
    "meanNumberOfRequestsPerSecond": {
        "total": "    81.69",
        "ok": "    81.33",
        "ko": "     0.36"
    }
},
contents: {
"req_go-to-login-pag-1537763987": {
        type: "REQUEST",
        name: "Go to login page",
path: "Go to login page",
pathFormatted: "req_go-to-login-pag-1537763987",
stats: {
    "name": "Go to login page",
    "numberOfRequests": {
        "total": "    1,463",
        "ok": "    1,463",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "       13",
        "ok": "       13",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "        1",
        "ok": "        1",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "        8",
        "ok": "        8",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1463,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.54",
        "ok": "     0.54",
        "ko": "        -"
    }
}
    },"req_submit-credenti--2043499788": {
        type: "REQUEST",
        name: "submit credentials",
path: "submit credentials",
pathFormatted: "req_submit-credenti--2043499788",
stats: {
    "name": "submit credentials",
    "numberOfRequests": {
        "total": "    1,463",
        "ok": "    1,267",
        "ko": "      196"
    },
    "minResponseTime": {
        "total": "      117",
        "ok": "      253",
        "ko": "      117"
    },
    "maxResponseTime": {
        "total": "   12,131",
        "ok": "   12,131",
        "ko": "    7,950"
    },
    "meanResponseTime": {
        "total": "    2,315",
        "ok": "    2,351",
        "ko": "    2,084"
    },
    "standardDeviation": {
        "total": "    1,928",
        "ok": "    2,020",
        "ko": "    1,150"
    },
    "percentiles1": {
        "total": "    1,618",
        "ok": "    1,685",
        "ko": "    1,566"
    },
    "percentiles2": {
        "total": "    3,070",
        "ok": "    3,248",
        "ko": "    2,158"
    },
    "percentiles3": {
        "total": "    6,301",
        "ok": "    6,481",
        "ko": "    4,747"
    },
    "percentiles4": {
        "total": "    9,084",
        "ok": "    9,357",
        "ko": "    6,830"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 340,
    "percentage": 23.239917976760083
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 142,
    "percentage": 9.706083390293916
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 785,
    "percentage": 53.65686944634312
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 196,
    "percentage": 13.397129186602871
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.54",
        "ok": "     0.47",
        "ko": "     0.07"
    }
}
    },"req_check-user-logg-946489478": {
        type: "REQUEST",
        name: "check user logged in",
path: "check user logged in",
pathFormatted: "req_check-user-logg-946489478",
stats: {
    "name": "check user logged in",
    "numberOfRequests": {
        "total": "    1,267",
        "ok": "    1,194",
        "ko": "       73"
    },
    "minResponseTime": {
        "total": "      483",
        "ok": "      483",
        "ko": "    1,527"
    },
    "maxResponseTime": {
        "total": "   21,893",
        "ok": "   21,893",
        "ko": "    9,676"
    },
    "meanResponseTime": {
        "total": "    3,417",
        "ok": "    3,485",
        "ko": "    2,308"
    },
    "standardDeviation": {
        "total": "    2,564",
        "ok": "    2,598",
        "ko": "    1,528"
    },
    "percentiles1": {
        "total": "    2,667",
        "ok": "    2,804",
        "ko": "    1,562"
    },
    "percentiles2": {
        "total": "    4,851",
        "ok": "    4,941",
        "ko": "    2,354"
    },
    "percentiles3": {
        "total": "    8,071",
        "ok": "    8,303",
        "ko": "    5,467"
    },
    "percentiles4": {
        "total": "   11,505",
        "ok": "   11,587",
        "ko": "    9,676"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 88,
    "percentage": 6.945540647198106
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 144,
    "percentage": 11.365430149960536
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 962,
    "percentage": 75.92738752959748
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 73,
    "percentage": 5.761641673243883
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.47",
        "ok": "     0.44",
        "ko": "     0.03"
    }
}
    },"req_go-to-user-prog--2104020333": {
        type: "REQUEST",
        name: "Go to user program page",
path: "Go to user program page",
pathFormatted: "req_go-to-user-prog--2104020333",
stats: {
    "name": "Go to user program page",
    "numberOfRequests": {
        "total": "    1,194",
        "ok": "    1,152",
        "ko": "       42"
    },
    "minResponseTime": {
        "total": "    1,415",
        "ok": "    1,415",
        "ko": "    1,528"
    },
    "maxResponseTime": {
        "total": "   34,062",
        "ok": "   34,062",
        "ko": "    5,016"
    },
    "meanResponseTime": {
        "total": "    8,251",
        "ok": "    8,471",
        "ko": "    2,211"
    },
    "standardDeviation": {
        "total": "    4,638",
        "ok": "    4,569",
        "ko": "    1,053"
    },
    "percentiles1": {
        "total": "    7,583",
        "ok": "    7,802",
        "ko": "    1,595"
    },
    "percentiles2": {
        "total": "   10,595",
        "ok": "   10,739",
        "ko": "    2,495"
    },
    "percentiles3": {
        "total": "   15,736",
        "ok": "   15,838",
        "ko": "    4,342"
    },
    "percentiles4": {
        "total": "   28,822",
        "ok": "   28,822",
        "ko": "    5,016"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 1152,
    "percentage": 96.4824120603015
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 42,
    "percentage": 3.5175879396984926
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.44",
        "ok": "     0.42",
        "ko": "     0.02"
    }
}
    },"req_go-to-breakout---1000037037": {
        type: "REQUEST",
        name: "Go to breakout page",
path: "Go to breakout page",
pathFormatted: "req_go-to-breakout---1000037037",
stats: {
    "name": "Go to breakout page",
    "numberOfRequests": {
        "total": "   10,620",
        "ok": "   10,584",
        "ko": "       36"
    },
    "minResponseTime": {
        "total": "      858",
        "ok": "      858",
        "ko": "    1,526"
    },
    "maxResponseTime": {
        "total": "   27,738",
        "ok": "   27,738",
        "ko": "    9,342"
    },
    "meanResponseTime": {
        "total": "    5,130",
        "ok": "    5,138",
        "ko": "    2,777"
    },
    "standardDeviation": {
        "total": "    3,138",
        "ok": "    3,139",
        "ko": "    1,873"
    },
    "percentiles1": {
        "total": "    4,581",
        "ok": "    4,590",
        "ko": "    1,734"
    },
    "percentiles2": {
        "total": "    6,655",
        "ok": "    6,661",
        "ko": "    3,363"
    },
    "percentiles3": {
        "total": "   11,140",
        "ok": "   11,149",
        "ko": "    7,887"
    },
    "percentiles4": {
        "total": "   15,412",
        "ok": "   15,420",
        "ko": "    9,342"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 106,
    "percentage": 0.9981167608286252
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10478,
    "percentage": 98.66290018832392
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 36,
    "percentage": 0.3389830508474576
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.92",
        "ok": "      3.9",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716124": {
        type: "REQUEST",
        name: "Accept vote (citation # 1)",
path: "Accept vote (citation # 1)",
pathFormatted: "req_accept-vote--ci--768716124",
stats: {
    "name": "Accept vote (citation # 1)",
    "numberOfRequests": {
        "total": "   10,584",
        "ok": "   10,549",
        "ko": "       35"
    },
    "minResponseTime": {
        "total": "       30",
        "ok": "      487",
        "ko": "       30"
    },
    "maxResponseTime": {
        "total": "   23,353",
        "ok": "   23,353",
        "ko": "    8,145"
    },
    "meanResponseTime": {
        "total": "    4,549",
        "ok": "    4,558",
        "ko": "    1,796"
    },
    "standardDeviation": {
        "total": "    2,555",
        "ok": "    2,552",
        "ko": "    1,801"
    },
    "percentiles1": {
        "total": "    4,102",
        "ok": "    4,111",
        "ko": "    1,535"
    },
    "percentiles2": {
        "total": "    5,910",
        "ok": "    5,916",
        "ko": "    2,234"
    },
    "percentiles3": {
        "total": "    9,332",
        "ok": "    9,339",
        "ko": "    5,493"
    },
    "percentiles4": {
        "total": "   12,822",
        "ok": "   12,828",
        "ko": "    8,145"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 41,
    "percentage": 0.3873771730914588
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 226,
    "percentage": 2.1352985638699926
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10282,
    "percentage": 97.14663643235072
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 35,
    "percentage": 0.3306878306878307
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.9",
        "ok": "     3.89",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826041": {
        type: "REQUEST",
        name: "Cancel vote (citation 1)",
path: "Cancel vote (citation 1)",
pathFormatted: "req_cancel-vote--ci-1326826041",
stats: {
    "name": "Cancel vote (citation 1)",
    "numberOfRequests": {
        "total": "   10,549",
        "ok": "   10,501",
        "ko": "       48"
    },
    "minResponseTime": {
        "total": "       28",
        "ok": "      512",
        "ko": "       28"
    },
    "maxResponseTime": {
        "total": "   27,128",
        "ok": "   27,128",
        "ko": "    8,986"
    },
    "meanResponseTime": {
        "total": "    4,674",
        "ok": "    4,686",
        "ko": "    2,120"
    },
    "standardDeviation": {
        "total": "    2,705",
        "ok": "    2,701",
        "ko": "    2,147"
    },
    "percentiles1": {
        "total": "    4,184",
        "ok": "    4,193",
        "ko": "    1,538"
    },
    "percentiles2": {
        "total": "    6,020",
        "ok": "    6,029",
        "ko": "    3,670"
    },
    "percentiles3": {
        "total": "    9,585",
        "ok": "    9,594",
        "ko": "    7,092"
    },
    "percentiles4": {
        "total": "   13,719",
        "ok": "   13,730",
        "ko": "    8,986"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 29,
    "percentage": 0.27490757417764716
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 177,
    "percentage": 1.6778841596359846
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10295,
    "percentage": 97.59218883306474
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 48,
    "percentage": 0.45501943312162296
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.89",
        "ok": "     3.87",
        "ko": "     0.02"
    }
}
    },"req_accept-vote--ci--768716093": {
        type: "REQUEST",
        name: "Accept vote (citation # 2)",
path: "Accept vote (citation # 2)",
pathFormatted: "req_accept-vote--ci--768716093",
stats: {
    "name": "Accept vote (citation # 2)",
    "numberOfRequests": {
        "total": "   10,501",
        "ok": "   10,466",
        "ko": "       35"
    },
    "minResponseTime": {
        "total": "       10",
        "ok": "      460",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   22,527",
        "ok": "   22,527",
        "ko": "    9,533"
    },
    "meanResponseTime": {
        "total": "    4,642",
        "ok": "    4,651",
        "ko": "    1,915"
    },
    "standardDeviation": {
        "total": "    2,619",
        "ok": "    2,615",
        "ko": "    2,301"
    },
    "percentiles1": {
        "total": "    4,152",
        "ok": "    4,160",
        "ko": "    1,538"
    },
    "percentiles2": {
        "total": "    6,044",
        "ok": "    6,049",
        "ko": "    1,584"
    },
    "percentiles3": {
        "total": "    9,680",
        "ok": "    9,687",
        "ko": "    7,510"
    },
    "percentiles4": {
        "total": "   13,103",
        "ok": "   13,109",
        "ko": "    9,533"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 34,
    "percentage": 0.32377868774402435
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 189,
    "percentage": 1.7998285877535474
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10243,
    "percentage": 97.5430911341777
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 35,
    "percentage": 0.333301590324731
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.87",
        "ok": "     3.86",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826072": {
        type: "REQUEST",
        name: "Cancel vote (citation 2)",
path: "Cancel vote (citation 2)",
pathFormatted: "req_cancel-vote--ci-1326826072",
stats: {
    "name": "Cancel vote (citation 2)",
    "numberOfRequests": {
        "total": "   10,466",
        "ok": "   10,440",
        "ko": "       26"
    },
    "minResponseTime": {
        "total": "      111",
        "ok": "      515",
        "ko": "      111"
    },
    "maxResponseTime": {
        "total": "   26,278",
        "ok": "   26,278",
        "ko": "    6,513"
    },
    "meanResponseTime": {
        "total": "    4,711",
        "ok": "    4,718",
        "ko": "    1,915"
    },
    "standardDeviation": {
        "total": "    2,682",
        "ok": "    2,680",
        "ko": "    1,820"
    },
    "percentiles1": {
        "total": "    4,217",
        "ok": "    4,222",
        "ko": "    1,547"
    },
    "percentiles2": {
        "total": "    6,046",
        "ok": "    6,050",
        "ko": "    3,267"
    },
    "percentiles3": {
        "total": "    9,741",
        "ok": "    9,747",
        "ko": "    5,028"
    },
    "percentiles4": {
        "total": "   13,751",
        "ok": "   13,759",
        "ko": "    6,513"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 22,
    "percentage": 0.21020447162239633
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 168,
    "percentage": 1.6051977832982993
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10250,
    "percentage": 97.93617427861648
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 26,
    "percentage": 0.24842346646283203
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.86",
        "ok": "     3.85",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155049977": {
        type: "REQUEST",
        name: "Reject vote (citation # 3)",
path: "Reject vote (citation # 3)",
pathFormatted: "req_reject-vote--ci-155049977",
stats: {
    "name": "Reject vote (citation # 3)",
    "numberOfRequests": {
        "total": "   10,440",
        "ok": "   10,405",
        "ko": "       35"
    },
    "minResponseTime": {
        "total": "       45",
        "ok": "      485",
        "ko": "       45"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   20,061",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    3,463",
        "ok": "    3,462",
        "ko": "    3,925"
    },
    "standardDeviation": {
        "total": "    2,666",
        "ok": "    2,609",
        "ko": "    9,852"
    },
    "percentiles1": {
        "total": "    2,863",
        "ok": "    2,866",
        "ko": "    1,542"
    },
    "percentiles2": {
        "total": "    4,785",
        "ok": "    4,788",
        "ko": "    3,556"
    },
    "percentiles3": {
        "total": "    8,529",
        "ok": "    8,533",
        "ko": "    7,712"
    },
    "percentiles4": {
        "total": "   12,543",
        "ok": "   12,540",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 800,
    "percentage": 7.662835249042145
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1385,
    "percentage": 13.266283524904216
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8220,
    "percentage": 78.73563218390804
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 35,
    "percentage": 0.33524904214559387
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.85",
        "ok": "     3.84",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200556": {
        type: "REQUEST",
        name: "Rejection reason (citation 3)",
path: "Rejection reason (citation 3)",
pathFormatted: "req_rejection-reaso-933200556",
stats: {
    "name": "Rejection reason (citation 3)",
    "numberOfRequests": {
        "total": "   10,405",
        "ok": "   10,372",
        "ko": "       33"
    },
    "minResponseTime": {
        "total": "       80",
        "ok": "      344",
        "ko": "       80"
    },
    "maxResponseTime": {
        "total": "   20,422",
        "ok": "   20,422",
        "ko": "    7,214"
    },
    "meanResponseTime": {
        "total": "    3,921",
        "ok": "    3,928",
        "ko": "    1,878"
    },
    "standardDeviation": {
        "total": "    2,379",
        "ok": "    2,378",
        "ko": "    1,673"
    },
    "percentiles1": {
        "total": "    3,422",
        "ok": "    3,428",
        "ko": "    1,539"
    },
    "percentiles2": {
        "total": "    5,206",
        "ok": "    5,211",
        "ko": "    2,366"
    },
    "percentiles3": {
        "total": "    8,410",
        "ok": "    8,417",
        "ko": "    5,397"
    },
    "percentiles4": {
        "total": "   11,862",
        "ok": "   11,869",
        "ko": "    7,214"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 156,
    "percentage": 1.4992791926958193
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 489,
    "percentage": 4.699663623258049
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9727,
    "percentage": 93.48390197020663
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 33,
    "percentage": 0.31715521383950024
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.84",
        "ok": "     3.82",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826103": {
        type: "REQUEST",
        name: "Cancel vote (citation 3)",
path: "Cancel vote (citation 3)",
pathFormatted: "req_cancel-vote--ci-1326826103",
stats: {
    "name": "Cancel vote (citation 3)",
    "numberOfRequests": {
        "total": "   10,372",
        "ok": "   10,341",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "        9",
        "ok": "      474",
        "ko": "        9"
    },
    "maxResponseTime": {
        "total": "   26,193",
        "ok": "   26,193",
        "ko": "    8,927"
    },
    "meanResponseTime": {
        "total": "    4,759",
        "ok": "    4,766",
        "ko": "    2,185"
    },
    "standardDeviation": {
        "total": "    2,762",
        "ok": "    2,759",
        "ko": "    2,427"
    },
    "percentiles1": {
        "total": "    4,198",
        "ok": "    4,205",
        "ko": "    1,559"
    },
    "percentiles2": {
        "total": "    6,078",
        "ok": "    6,081",
        "ko": "    2,830"
    },
    "percentiles3": {
        "total": "    9,949",
        "ok": "    9,956",
        "ko": "    8,898"
    },
    "percentiles4": {
        "total": "   14,483",
        "ok": "   14,494",
        "ko": "    8,927"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 17,
    "percentage": 0.16390281527188585
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 144,
    "percentage": 1.3883532587736214
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10180,
    "percentage": 98.14886232163516
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.29888160431932126
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.82",
        "ok": "     3.81",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050008": {
        type: "REQUEST",
        name: "Reject vote (citation # 4)",
path: "Reject vote (citation # 4)",
pathFormatted: "req_reject-vote--ci-155050008",
stats: {
    "name": "Reject vote (citation # 4)",
    "numberOfRequests": {
        "total": "   10,341",
        "ok": "   10,308",
        "ko": "       33"
    },
    "minResponseTime": {
        "total": "       23",
        "ok": "      496",
        "ko": "       23"
    },
    "maxResponseTime": {
        "total": "   20,292",
        "ok": "   20,292",
        "ko": "    8,572"
    },
    "meanResponseTime": {
        "total": "    3,396",
        "ok": "    3,402",
        "ko": "    1,728"
    },
    "standardDeviation": {
        "total": "    2,524",
        "ok": "    2,523",
        "ko": "    1,996"
    },
    "percentiles1": {
        "total": "    2,835",
        "ok": "    2,842",
        "ko": "    1,531"
    },
    "percentiles2": {
        "total": "    4,691",
        "ok": "    4,695",
        "ko": "    1,601"
    },
    "percentiles3": {
        "total": "    8,365",
        "ok": "    8,370",
        "ko": "    6,270"
    },
    "percentiles4": {
        "total": "   11,807",
        "ok": "   11,813",
        "ko": "    8,572"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 771,
    "percentage": 7.455758630693357
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1445,
    "percentage": 13.9735035296393
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8092,
    "percentage": 78.25161976598008
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 33,
    "percentage": 0.3191180736872643
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.81",
        "ok": "      3.8",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200587": {
        type: "REQUEST",
        name: "Rejection reason (citation 4)",
path: "Rejection reason (citation 4)",
pathFormatted: "req_rejection-reaso-933200587",
stats: {
    "name": "Rejection reason (citation 4)",
    "numberOfRequests": {
        "total": "   10,308",
        "ok": "   10,293",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "       59",
        "ok": "      306",
        "ko": "       59"
    },
    "maxResponseTime": {
        "total": "   19,758",
        "ok": "   19,758",
        "ko": "    9,390"
    },
    "meanResponseTime": {
        "total": "    3,974",
        "ok": "    3,977",
        "ko": "    2,246"
    },
    "standardDeviation": {
        "total": "    2,442",
        "ok": "    2,440",
        "ko": "    3,003"
    },
    "percentiles1": {
        "total": "    3,418",
        "ok": "    3,421",
        "ko": "      685"
    },
    "percentiles2": {
        "total": "    5,245",
        "ok": "    5,246",
        "ko": "    2,559"
    },
    "percentiles3": {
        "total": "    8,701",
        "ok": "    8,695",
        "ko": "    9,390"
    },
    "percentiles4": {
        "total": "   11,958",
        "ok": "   11,960",
        "ko": "    9,390"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 162,
    "percentage": 1.571594877764843
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 489,
    "percentage": 4.743888242142026
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9642,
    "percentage": 93.53899883585565
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.14551804423748546
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.8",
        "ok": "      3.8",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826134": {
        type: "REQUEST",
        name: "Cancel vote (citation 4)",
path: "Cancel vote (citation 4)",
pathFormatted: "req_cancel-vote--ci-1326826134",
stats: {
    "name": "Cancel vote (citation 4)",
    "numberOfRequests": {
        "total": "   10,293",
        "ok": "   10,265",
        "ko": "       28"
    },
    "minResponseTime": {
        "total": "       10",
        "ok": "      551",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   27,208",
        "ok": "   27,208",
        "ko": "    9,005"
    },
    "meanResponseTime": {
        "total": "    4,850",
        "ok": "    4,859",
        "ko": "    1,739"
    },
    "standardDeviation": {
        "total": "    2,773",
        "ok": "    2,770",
        "ko": "    2,067"
    },
    "percentiles1": {
        "total": "    4,335",
        "ok": "    4,343",
        "ko": "    1,542"
    },
    "percentiles2": {
        "total": "    6,196",
        "ok": "    6,200",
        "ko": "    1,743"
    },
    "percentiles3": {
        "total": "    9,901",
        "ok": "    9,910",
        "ko": "    7,797"
    },
    "percentiles4": {
        "total": "   14,509",
        "ok": "   14,516",
        "ko": "    9,005"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 15,
    "percentage": 0.1457301078402798
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 126,
    "percentage": 1.2241329058583503
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10124,
    "percentage": 98.35810745166617
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 28,
    "percentage": 0.272029534635189
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.8",
        "ok": "     3.79",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716000": {
        type: "REQUEST",
        name: "Accept vote (citation # 5)",
path: "Accept vote (citation # 5)",
pathFormatted: "req_accept-vote--ci--768716000",
stats: {
    "name": "Accept vote (citation # 5)",
    "numberOfRequests": {
        "total": "   10,265",
        "ok": "   10,234",
        "ko": "       31"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      643",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   23,143",
        "ok": "   23,143",
        "ko": "    9,581"
    },
    "meanResponseTime": {
        "total": "    4,836",
        "ok": "    4,844",
        "ko": "    2,291"
    },
    "standardDeviation": {
        "total": "    2,669",
        "ok": "    2,665",
        "ko": "    2,762"
    },
    "percentiles1": {
        "total": "    4,360",
        "ok": "    4,366",
        "ko": "    1,547"
    },
    "percentiles2": {
        "total": "    6,209",
        "ok": "    6,213",
        "ko": "    2,546"
    },
    "percentiles3": {
        "total": "    9,928",
        "ok": "    9,937",
        "ko": "    9,065"
    },
    "percentiles4": {
        "total": "   13,662",
        "ok": "   13,669",
        "ko": "    9,581"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 0.11690209449585973
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 127,
    "percentage": 1.2372138334145153
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10095,
    "percentage": 98.34388699464198
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 31,
    "percentage": 0.3019970774476376
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.79",
        "ok": "     3.77",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826165": {
        type: "REQUEST",
        name: "Cancel vote (citation 5)",
path: "Cancel vote (citation 5)",
pathFormatted: "req_cancel-vote--ci-1326826165",
stats: {
    "name": "Cancel vote (citation 5)",
    "numberOfRequests": {
        "total": "   10,234",
        "ok": "   10,206",
        "ko": "       28"
    },
    "minResponseTime": {
        "total": "       78",
        "ok": "      588",
        "ko": "       78"
    },
    "maxResponseTime": {
        "total": "   26,631",
        "ok": "   26,631",
        "ko": "    4,813"
    },
    "meanResponseTime": {
        "total": "    4,934",
        "ok": "    4,943",
        "ko": "    1,631"
    },
    "standardDeviation": {
        "total": "    2,744",
        "ok": "    2,741",
        "ko": "    1,402"
    },
    "percentiles1": {
        "total": "    4,435",
        "ok": "    4,442",
        "ko": "    1,533"
    },
    "percentiles2": {
        "total": "    6,245",
        "ok": "    6,251",
        "ko": "    2,395"
    },
    "percentiles3": {
        "total": "   10,047",
        "ok": "   10,054",
        "ko": "    4,809"
    },
    "percentiles4": {
        "total": "   14,066",
        "ok": "   14,071",
        "ko": "    4,813"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 15,
    "percentage": 0.1465702560093805
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 95,
    "percentage": 0.9282782880594097
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10096,
    "percentage": 98.6515536447137
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 28,
    "percentage": 0.27359781121751026
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.77",
        "ok": "     3.76",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768715969": {
        type: "REQUEST",
        name: "Accept vote (citation # 6)",
path: "Accept vote (citation # 6)",
pathFormatted: "req_accept-vote--ci--768715969",
stats: {
    "name": "Accept vote (citation # 6)",
    "numberOfRequests": {
        "total": "   10,206",
        "ok": "   10,177",
        "ko": "       29"
    },
    "minResponseTime": {
        "total": "       14",
        "ok": "      681",
        "ko": "       14"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   23,228",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,013",
        "ok": "    5,010",
        "ko": "    6,102"
    },
    "standardDeviation": {
        "total": "    2,875",
        "ok": "    2,766",
        "ko": "   14,896"
    },
    "percentiles1": {
        "total": "    4,522",
        "ok": "    4,528",
        "ko": "    1,540"
    },
    "percentiles2": {
        "total": "    6,392",
        "ok": "    6,394",
        "ko": "    2,894"
    },
    "percentiles3": {
        "total": "   10,454",
        "ok": "   10,450",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   14,001",
        "ok": "   13,964",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 8,
    "percentage": 0.07838526357044875
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 100,
    "percentage": 0.9798157946306094
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10069,
    "percentage": 98.65765236135606
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 29,
    "percentage": 0.2841465804428768
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.76",
        "ok": "     3.75",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826196": {
        type: "REQUEST",
        name: "Cancel vote (citation 6)",
path: "Cancel vote (citation 6)",
pathFormatted: "req_cancel-vote--ci-1326826196",
stats: {
    "name": "Cancel vote (citation 6)",
    "numberOfRequests": {
        "total": "   10,177",
        "ok": "   10,137",
        "ko": "       40"
    },
    "minResponseTime": {
        "total": "       16",
        "ok": "      613",
        "ko": "       16"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   27,714",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,087",
        "ok": "    5,089",
        "ko": "    4,499"
    },
    "standardDeviation": {
        "total": "    2,952",
        "ok": "    2,846",
        "ko": "   12,796"
    },
    "percentiles1": {
        "total": "    4,576",
        "ok": "    4,586",
        "ko": "    1,550"
    },
    "percentiles2": {
        "total": "    6,401",
        "ok": "    6,407",
        "ko": "    2,608"
    },
    "percentiles3": {
        "total": "   10,282",
        "ok": "   10,282",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   14,896",
        "ok": "   14,831",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 10,
    "percentage": 0.09826078412105729
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 86,
    "percentage": 0.8450427434410928
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10041,
    "percentage": 98.66365333595361
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 40,
    "percentage": 0.39304313648422917
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.75",
        "ok": "     3.74",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050101": {
        type: "REQUEST",
        name: "Reject vote (citation # 7)",
path: "Reject vote (citation # 7)",
pathFormatted: "req_reject-vote--ci-155050101",
stats: {
    "name": "Reject vote (citation # 7)",
    "numberOfRequests": {
        "total": "   10,137",
        "ok": "   10,110",
        "ko": "       27"
    },
    "minResponseTime": {
        "total": "       22",
        "ok": "      470",
        "ko": "       22"
    },
    "maxResponseTime": {
        "total": "   18,428",
        "ok": "   18,428",
        "ko": "    9,646"
    },
    "meanResponseTime": {
        "total": "    3,389",
        "ok": "    3,392",
        "ko": "    1,940"
    },
    "standardDeviation": {
        "total": "    2,526",
        "ok": "    2,525",
        "ko": "    2,443"
    },
    "percentiles1": {
        "total": "    2,865",
        "ok": "    2,867",
        "ko": "    1,531"
    },
    "percentiles2": {
        "total": "    4,673",
        "ok": "    4,675",
        "ko": "    1,639"
    },
    "percentiles3": {
        "total": "    8,463",
        "ok": "    8,465",
        "ko": "    7,912"
    },
    "percentiles4": {
        "total": "   12,058",
        "ok": "   12,064",
        "ko": "    9,646"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 822,
    "percentage": 8.108907960935188
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1350,
    "percentage": 13.317549570878958
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7938,
    "percentage": 78.30719147676828
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27,
    "percentage": 0.2663509914175792
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.74",
        "ok": "     3.73",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200680": {
        type: "REQUEST",
        name: "Rejection reason (citation 7)",
path: "Rejection reason (citation 7)",
pathFormatted: "req_rejection-reaso-933200680",
stats: {
    "name": "Rejection reason (citation 7)",
    "numberOfRequests": {
        "total": "   10,110",
        "ok": "   10,078",
        "ko": "       32"
    },
    "minResponseTime": {
        "total": "       48",
        "ok": "      288",
        "ko": "       48"
    },
    "maxResponseTime": {
        "total": "   19,487",
        "ok": "   19,487",
        "ko": "    9,813"
    },
    "meanResponseTime": {
        "total": "    3,938",
        "ok": "    3,944",
        "ko": "    2,077"
    },
    "standardDeviation": {
        "total": "    2,443",
        "ok": "    2,440",
        "ko": "    2,780"
    },
    "percentiles1": {
        "total": "    3,405",
        "ok": "    3,412",
        "ko": "    1,528"
    },
    "percentiles2": {
        "total": "    5,189",
        "ok": "    5,191",
        "ko": "    2,503"
    },
    "percentiles3": {
        "total": "    8,638",
        "ok": "    8,634",
        "ko": "    9,260"
    },
    "percentiles4": {
        "total": "   12,152",
        "ok": "   12,171",
        "ko": "    9,813"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 184,
    "percentage": 1.8199802176063304
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 496,
    "percentage": 4.906033630069238
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9398,
    "percentage": 92.95746785361028
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 32,
    "percentage": 0.3165182987141444
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.73",
        "ok": "     3.72",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826227": {
        type: "REQUEST",
        name: "Cancel vote (citation 7)",
path: "Cancel vote (citation 7)",
pathFormatted: "req_cancel-vote--ci-1326826227",
stats: {
    "name": "Cancel vote (citation 7)",
    "numberOfRequests": {
        "total": "   10,078",
        "ok": "   10,051",
        "ko": "       27"
    },
    "minResponseTime": {
        "total": "       35",
        "ok": "      661",
        "ko": "       35"
    },
    "maxResponseTime": {
        "total": "   25,940",
        "ok": "   25,940",
        "ko": "    9,416"
    },
    "meanResponseTime": {
        "total": "    5,117",
        "ok": "    5,124",
        "ko": "    2,619"
    },
    "standardDeviation": {
        "total": "    2,839",
        "ok": "    2,836",
        "ko": "    2,744"
    },
    "percentiles1": {
        "total": "    4,613",
        "ok": "    4,618",
        "ko": "    1,653"
    },
    "percentiles2": {
        "total": "    6,518",
        "ok": "    6,522",
        "ko": "    3,552"
    },
    "percentiles3": {
        "total": "   10,432",
        "ok": "   10,441",
        "ko": "    9,066"
    },
    "percentiles4": {
        "total": "   14,640",
        "ok": "   14,647",
        "ko": "    9,416"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 16,
    "percentage": 0.15876165905933717
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 94,
    "percentage": 0.932724746973606
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9941,
    "percentage": 98.64060329430443
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27,
    "percentage": 0.26791029966263147
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.72",
        "ok": "     3.71",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050132": {
        type: "REQUEST",
        name: "Reject vote (citation # 8)",
path: "Reject vote (citation # 8)",
pathFormatted: "req_reject-vote--ci-155050132",
stats: {
    "name": "Reject vote (citation # 8)",
    "numberOfRequests": {
        "total": "   10,051",
        "ok": "   10,025",
        "ko": "       26"
    },
    "minResponseTime": {
        "total": "      163",
        "ok": "      474",
        "ko": "      163"
    },
    "maxResponseTime": {
        "total": "   20,827",
        "ok": "   20,827",
        "ko": "    8,355"
    },
    "meanResponseTime": {
        "total": "    3,389",
        "ok": "    3,392",
        "ko": "    2,511"
    },
    "standardDeviation": {
        "total": "    2,511",
        "ok": "    2,511",
        "ko": "    2,328"
    },
    "percentiles1": {
        "total": "    2,909",
        "ok": "    2,912",
        "ko": "    1,556"
    },
    "percentiles2": {
        "total": "    4,667",
        "ok": "    4,668",
        "ko": "    4,555"
    },
    "percentiles3": {
        "total": "    8,229",
        "ok": "    8,232",
        "ko": "    7,365"
    },
    "percentiles4": {
        "total": "   12,130",
        "ok": "   12,134",
        "ko": "    8,355"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 811,
    "percentage": 8.068848870759128
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1368,
    "percentage": 13.610586011342155
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7846,
    "percentage": 78.06188438961298
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 26,
    "percentage": 0.25868072828574273
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.71",
        "ok": "      3.7",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200711": {
        type: "REQUEST",
        name: "Rejection reason (citation 8)",
path: "Rejection reason (citation 8)",
pathFormatted: "req_rejection-reaso-933200711",
stats: {
    "name": "Rejection reason (citation 8)",
    "numberOfRequests": {
        "total": "   10,025",
        "ok": "    9,991",
        "ko": "       34"
    },
    "minResponseTime": {
        "total": "       17",
        "ok": "      351",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   20,444",
        "ok": "   20,444",
        "ko": "    6,380"
    },
    "meanResponseTime": {
        "total": "    3,967",
        "ok": "    3,975",
        "ko": "    1,787"
    },
    "standardDeviation": {
        "total": "    2,478",
        "ok": "    2,477",
        "ko": "    1,768"
    },
    "percentiles1": {
        "total": "    3,454",
        "ok": "    3,459",
        "ko": "    1,540"
    },
    "percentiles2": {
        "total": "    5,250",
        "ok": "    5,255",
        "ko": "    2,865"
    },
    "percentiles3": {
        "total": "    8,706",
        "ok": "    8,715",
        "ko": "    5,447"
    },
    "percentiles4": {
        "total": "   12,199",
        "ok": "   12,208",
        "ko": "    6,380"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 187,
    "percentage": 1.8653366583541147
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 502,
    "percentage": 5.007481296758105
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9302,
    "percentage": 92.78802992518703
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 34,
    "percentage": 0.3391521197007481
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.7",
        "ok": "     3.68",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826258": {
        type: "REQUEST",
        name: "Cancel vote (citation 8)",
path: "Cancel vote (citation 8)",
pathFormatted: "req_cancel-vote--ci-1326826258",
stats: {
    "name": "Cancel vote (citation 8)",
    "numberOfRequests": {
        "total": "    9,991",
        "ok": "    9,964",
        "ko": "       27"
    },
    "minResponseTime": {
        "total": "       12",
        "ok": "      626",
        "ko": "       12"
    },
    "maxResponseTime": {
        "total": "   29,374",
        "ok": "   29,374",
        "ko": "    7,617"
    },
    "meanResponseTime": {
        "total": "    5,222",
        "ok": "    5,231",
        "ko": "    1,830"
    },
    "standardDeviation": {
        "total": "    2,937",
        "ok": "    2,934",
        "ko": "    1,721"
    },
    "percentiles1": {
        "total": "    4,717",
        "ok": "    4,726",
        "ko": "    1,551"
    },
    "percentiles2": {
        "total": "    6,623",
        "ok": "    6,628",
        "ko": "    3,244"
    },
    "percentiles3": {
        "total": "   10,799",
        "ok": "   10,806",
        "ko": "    4,428"
    },
    "percentiles4": {
        "total": "   15,157",
        "ok": "   15,167",
        "ko": "    7,617"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5,
    "percentage": 0.050045040536482836
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 74,
    "percentage": 0.740666599939946
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9885,
    "percentage": 98.93904514062658
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 27,
    "percentage": 0.2702432188970073
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.68",
        "ok": "     3.67",
        "ko": "     0.01"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
