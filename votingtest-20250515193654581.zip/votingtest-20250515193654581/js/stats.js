var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "  177,490",
        "ok": "  177,011",
        "ko": "      479"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        9"
    },
    "maxResponseTime": {
        "total": "   60,001",
        "ok": "   58,589",
        "ko": "   60,001"
    },
    "meanResponseTime": {
        "total": "    6,623",
        "ok": "    6,630",
        "ko": "    3,755"
    },
    "standardDeviation": {
        "total": "    9,486",
        "ok": "    9,475",
        "ko": "   12,704"
    },
    "percentiles1": {
        "total": "    2,398",
        "ok": "    2,402",
        "ko": "      514"
    },
    "percentiles2": {
        "total": "    5,400",
        "ok": "    5,423",
        "ko": "    1,237"
    },
    "percentiles3": {
        "total": "   29,521",
        "ok": "   29,530",
        "ko": "   14,482"
    },
    "percentiles4": {
        "total": "   38,670",
        "ok": "   38,641",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 13082,
    "percentage": 7.37055608766691
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 18222,
    "percentage": 10.266493886979548
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 145707,
    "percentage": 82.09307566623471
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 479,
    "percentage": 0.26987435911882357
},
    "meanNumberOfRequestsPerSecond": {
        "total": "    52.13",
        "ok": "    51.99",
        "ko": "     0.14"
    }
},
contents: {
"req_go-to-login-pag-1537763987": {
        type: "REQUEST",
        name: "Go to login page",
path: "Go to login page",
pathFormatted: "req_go-to-login-pag-1537763987",
stats: {
    "name": "Go to login page",
    "numberOfRequests": {
        "total": "      933",
        "ok": "      933",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "       12",
        "ok": "       12",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "        1",
        "ok": "        1",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "        7",
        "ok": "        7",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 933,
    "percentage": 100.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.27",
        "ok": "     0.27",
        "ko": "        -"
    }
}
    },"req_submit-credenti--2043499788": {
        type: "REQUEST",
        name: "submit credentials",
path: "submit credentials",
pathFormatted: "req_submit-credenti--2043499788",
stats: {
    "name": "submit credentials",
    "numberOfRequests": {
        "total": "      933",
        "ok": "      933",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "      255",
        "ok": "      255",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   40,842",
        "ok": "   40,842",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    3,106",
        "ok": "    3,106",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    6,339",
        "ok": "    6,339",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "      672",
        "ok": "      672",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    1,961",
        "ok": "    1,961",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   17,534",
        "ok": "   17,550",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   31,801",
        "ok": "   31,801",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 543,
    "percentage": 58.19935691318327
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 94,
    "percentage": 10.07502679528403
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 296,
    "percentage": 31.72561629153269
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.27",
        "ok": "     0.27",
        "ko": "        -"
    }
}
    },"req_check-user-logg-946489478": {
        type: "REQUEST",
        name: "check user logged in",
path: "check user logged in",
pathFormatted: "req_check-user-logg-946489478",
stats: {
    "name": "check user logged in",
    "numberOfRequests": {
        "total": "      933",
        "ok": "      932",
        "ko": "        1"
    },
    "minResponseTime": {
        "total": "      470",
        "ok": "      470",
        "ko": "   60,000"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   43,836",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    4,239",
        "ok": "    4,179",
        "ko": "   60,000"
    },
    "standardDeviation": {
        "total": "    7,242",
        "ok": "    7,011",
        "ko": "        0"
    },
    "percentiles1": {
        "total": "    1,304",
        "ok": "    1,303",
        "ko": "   60,000"
    },
    "percentiles2": {
        "total": "    3,200",
        "ok": "    3,184",
        "ko": "   60,000"
    },
    "percentiles3": {
        "total": "   20,640",
        "ok": "   20,289",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   33,819",
        "ok": "   33,512",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 199,
    "percentage": 21.329046087888532
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 215,
    "percentage": 23.04394426580922
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 518,
    "percentage": 55.519828510182215
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 0.10718113612004287
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.27",
        "ok": "     0.27",
        "ko": "        0"
    }
}
    },"req_go-to-user-prog--2104020333": {
        type: "REQUEST",
        name: "Go to user program page",
path: "Go to user program page",
pathFormatted: "req_go-to-user-prog--2104020333",
stats: {
    "name": "Go to user program page",
    "numberOfRequests": {
        "total": "      932",
        "ok": "      932",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "      708",
        "ok": "      708",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   49,865",
        "ok": "   49,865",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    6,222",
        "ok": "    6,222",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    8,173",
        "ok": "    8,173",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    2,948",
        "ok": "    2,948",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    5,639",
        "ok": "    5,639",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   25,316",
        "ok": "   25,316",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   39,280",
        "ok": "   39,280",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 4,
    "percentage": 0.4291845493562232
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 40,
    "percentage": 4.291845493562231
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 888,
    "percentage": 95.27896995708154
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.27",
        "ok": "     0.27",
        "ko": "        -"
    }
}
    },"req_go-to-breakout---1000037037": {
        type: "REQUEST",
        name: "Go to breakout page",
path: "Go to breakout page",
pathFormatted: "req_go-to-breakout---1000037037",
stats: {
    "name": "Go to breakout page",
    "numberOfRequests": {
        "total": "    8,424",
        "ok": "    8,422",
        "ko": "        2"
    },
    "minResponseTime": {
        "total": "      847",
        "ok": "      847",
        "ko": "   60,000"
    },
    "maxResponseTime": {
        "total": "   60,001",
        "ok": "   54,418",
        "ko": "   60,001"
    },
    "meanResponseTime": {
        "total": "    7,984",
        "ok": "    7,972",
        "ko": "   60,001"
    },
    "standardDeviation": {
        "total": "   10,983",
        "ok": "   10,955",
        "ko": "        1"
    },
    "percentiles1": {
        "total": "    2,675",
        "ok": "    2,674",
        "ko": "   60,001"
    },
    "percentiles2": {
        "total": "    7,343",
        "ok": "    7,335",
        "ko": "   60,001"
    },
    "percentiles3": {
        "total": "   34,369",
        "ok": "   34,335",
        "ko": "   60,001"
    },
    "percentiles4": {
        "total": "   43,156",
        "ok": "   42,852",
        "ko": "   60,001"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 679,
    "percentage": 8.060303893637228
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7743,
    "percentage": 91.91595441595442
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 2,
    "percentage": 0.023741690408357077
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.47",
        "ok": "     2.47",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768716124": {
        type: "REQUEST",
        name: "Accept vote (citation # 1)",
path: "Accept vote (citation # 1)",
pathFormatted: "req_accept-vote--ci--768716124",
stats: {
    "name": "Accept vote (citation # 1)",
    "numberOfRequests": {
        "total": "    8,422",
        "ok": "    8,408",
        "ko": "       14"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      397",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   48,910",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,474",
        "ok": "    6,477",
        "ko": "    4,897"
    },
    "standardDeviation": {
        "total": "    8,974",
        "ok": "    8,960",
        "ko": "   15,299"
    },
    "percentiles1": {
        "total": "    2,447",
        "ok": "    2,449",
        "ko": "      655"
    },
    "percentiles2": {
        "total": "    5,127",
        "ok": "    5,138",
        "ko": "      907"
    },
    "percentiles3": {
        "total": "   28,608",
        "ok": "   28,601",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   36,205",
        "ok": "   36,150",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 265,
    "percentage": 3.1465210163856567
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 701,
    "percentage": 8.32343861315602
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7442,
    "percentage": 88.36380907147947
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0.16623129897886488
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.47",
        "ok": "     2.47",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826041": {
        type: "REQUEST",
        name: "Cancel vote (citation 1)",
path: "Cancel vote (citation 1)",
pathFormatted: "req_cancel-vote--ci-1326826041",
stats: {
    "name": "Cancel vote (citation 1)",
    "numberOfRequests": {
        "total": "    8,408",
        "ok": "    8,386",
        "ko": "       22"
    },
    "minResponseTime": {
        "total": "       22",
        "ok": "      441",
        "ko": "       22"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   52,607",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,749",
        "ok": "    6,751",
        "ko": "    5,981"
    },
    "standardDeviation": {
        "total": "    9,557",
        "ok": "    9,529",
        "ko": "   17,095"
    },
    "percentiles1": {
        "total": "    2,484",
        "ok": "    2,487",
        "ko": "      525"
    },
    "percentiles2": {
        "total": "    5,385",
        "ok": "    5,398",
        "ko": "    1,219"
    },
    "percentiles3": {
        "total": "   29,527",
        "ok": "   29,507",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   41,153",
        "ok": "   41,010",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 234,
    "percentage": 2.7830637488106564
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 695,
    "percentage": 8.26593720266413
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7457,
    "percentage": 88.68934348239772
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22,
    "percentage": 0.26165556612749763
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.47",
        "ok": "     2.46",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716093": {
        type: "REQUEST",
        name: "Accept vote (citation # 2)",
path: "Accept vote (citation # 2)",
pathFormatted: "req_accept-vote--ci--768716093",
stats: {
    "name": "Accept vote (citation # 2)",
    "numberOfRequests": {
        "total": "    8,386",
        "ok": "    8,367",
        "ko": "       19"
    },
    "minResponseTime": {
        "total": "       14",
        "ok": "      395",
        "ko": "       14"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   48,195",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,444",
        "ok": "    6,443",
        "ko": "    6,969"
    },
    "standardDeviation": {
        "total": "    8,953",
        "ok": "    8,921",
        "ko": "   18,200"
    },
    "percentiles1": {
        "total": "    2,508",
        "ok": "    2,511",
        "ko": "      652"
    },
    "percentiles2": {
        "total": "    5,077",
        "ok": "    5,087",
        "ko": "    1,711"
    },
    "percentiles3": {
        "total": "   28,842",
        "ok": "   28,830",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   36,239",
        "ok": "   36,241",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 226,
    "percentage": 2.6949678034819935
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 657,
    "percentage": 7.83448604817553
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7484,
    "percentage": 89.24397805866921
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19,
    "percentage": 0.22656808967326494
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.46",
        "ok": "     2.46",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826072": {
        type: "REQUEST",
        name: "Cancel vote (citation 2)",
path: "Cancel vote (citation 2)",
pathFormatted: "req_cancel-vote--ci-1326826072",
stats: {
    "name": "Cancel vote (citation 2)",
    "numberOfRequests": {
        "total": "    8,367",
        "ok": "    8,349",
        "ko": "       18"
    },
    "minResponseTime": {
        "total": "       20",
        "ok": "      418",
        "ko": "       20"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   53,260",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,795",
        "ok": "    6,801",
        "ko": "    4,288"
    },
    "standardDeviation": {
        "total": "    9,489",
        "ok": "    9,478",
        "ko": "   13,545"
    },
    "percentiles1": {
        "total": "    2,556",
        "ok": "    2,559",
        "ko": "    1,084"
    },
    "percentiles2": {
        "total": "    5,329",
        "ok": "    5,342",
        "ko": "    2,152"
    },
    "percentiles3": {
        "total": "   29,098",
        "ok": "   29,097",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   40,723",
        "ok": "   40,704",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 203,
    "percentage": 2.426198159435879
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 594,
    "percentage": 7.099318752240946
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7552,
    "percentage": 90.25935221704314
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 18,
    "percentage": 0.2151308712800287
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.46",
        "ok": "     2.45",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155049977": {
        type: "REQUEST",
        name: "Reject vote (citation # 3)",
path: "Reject vote (citation # 3)",
pathFormatted: "req_reject-vote--ci-155049977",
stats: {
    "name": "Reject vote (citation # 3)",
    "numberOfRequests": {
        "total": "    8,349",
        "ok": "    8,336",
        "ko": "       13"
    },
    "minResponseTime": {
        "total": "       77",
        "ok": "      461",
        "ko": "       77"
    },
    "maxResponseTime": {
        "total": "   48,634",
        "ok": "   48,634",
        "ko": "    2,039"
    },
    "meanResponseTime": {
        "total": "    5,988",
        "ok": "    5,996",
        "ko": "      822"
    },
    "standardDeviation": {
        "total": "    9,378",
        "ok": "    9,383",
        "ko": "      617"
    },
    "percentiles1": {
        "total": "    1,454",
        "ok": "    1,457",
        "ko": "      707"
    },
    "percentiles2": {
        "total": "    4,827",
        "ok": "    4,840",
        "ko": "    1,091"
    },
    "percentiles3": {
        "total": "   29,219",
        "ok": "   29,226",
        "ko": "    2,039"
    },
    "percentiles4": {
        "total": "   35,880",
        "ok": "   35,860",
        "ko": "    2,039"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1762,
    "percentage": 21.10432387112229
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1809,
    "percentage": 21.66726554078333
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4765,
    "percentage": 57.07270331776261
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0.15570727033177625
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.45",
        "ok": "     2.45",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200556": {
        type: "REQUEST",
        name: "Rejection reason (citation 3)",
path: "Rejection reason (citation 3)",
pathFormatted: "req_rejection-reaso-933200556",
stats: {
    "name": "Rejection reason (citation 3)",
    "numberOfRequests": {
        "total": "    8,336",
        "ok": "    8,317",
        "ko": "       19"
    },
    "minResponseTime": {
        "total": "       10",
        "ok": "      310",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   46,928",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,931",
        "ok": "    5,936",
        "ko": "    3,781"
    },
    "standardDeviation": {
        "total": "    8,664",
        "ok": "    8,650",
        "ko": "   13,275"
    },
    "percentiles1": {
        "total": "    2,125",
        "ok": "    2,127",
        "ko": "      485"
    },
    "percentiles2": {
        "total": "    4,320",
        "ok": "    4,332",
        "ko": "    1,018"
    },
    "percentiles3": {
        "total": "   27,310",
        "ok": "   27,309",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   35,316",
        "ok": "   35,272",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 622,
    "percentage": 7.461612284069099
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 949,
    "percentage": 11.384357005758156
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6746,
    "percentage": 80.92610364683301
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19,
    "percentage": 0.22792706333973128
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.45",
        "ok": "     2.44",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826103": {
        type: "REQUEST",
        name: "Cancel vote (citation 3)",
path: "Cancel vote (citation 3)",
pathFormatted: "req_cancel-vote--ci-1326826103",
stats: {
    "name": "Cancel vote (citation 3)",
    "numberOfRequests": {
        "total": "    8,317",
        "ok": "    8,293",
        "ko": "       24"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      422",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   55,195",
        "ok": "   55,195",
        "ko": "    2,653"
    },
    "meanResponseTime": {
        "total": "    6,817",
        "ok": "    6,834",
        "ko": "      850"
    },
    "standardDeviation": {
        "total": "    9,421",
        "ok": "    9,429",
        "ko": "      782"
    },
    "percentiles1": {
        "total": "    2,576",
        "ok": "    2,582",
        "ko": "      892"
    },
    "percentiles2": {
        "total": "    5,533",
        "ok": "    5,563",
        "ko": "    1,343"
    },
    "percentiles3": {
        "total": "   29,363",
        "ok": "   29,383",
        "ko": "    2,334"
    },
    "percentiles4": {
        "total": "   40,323",
        "ok": "   40,341",
        "ko": "    2,653"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 176,
    "percentage": 2.11614764939281
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 567,
    "percentage": 6.817362029577972
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7550,
    "percentage": 90.77792473247565
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 24,
    "percentage": 0.288565588553565
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.44",
        "ok": "     2.44",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050008": {
        type: "REQUEST",
        name: "Reject vote (citation # 4)",
path: "Reject vote (citation # 4)",
pathFormatted: "req_reject-vote--ci-155050008",
stats: {
    "name": "Reject vote (citation # 4)",
    "numberOfRequests": {
        "total": "    8,293",
        "ok": "    8,278",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "      152",
        "ok": "      460",
        "ko": "      152"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   47,677",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,891",
        "ok": "    5,892",
        "ko": "    4,821"
    },
    "standardDeviation": {
        "total": "    9,358",
        "ok": "    9,345",
        "ko": "   14,767"
    },
    "percentiles1": {
        "total": "    1,411",
        "ok": "    1,414",
        "ko": "      599"
    },
    "percentiles2": {
        "total": "    4,477",
        "ok": "    4,489",
        "ko": "    1,369"
    },
    "percentiles3": {
        "total": "   29,096",
        "ok": "   29,101",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   36,211",
        "ok": "   35,997",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1808,
    "percentage": 21.80151935367177
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1815,
    "percentage": 21.885927890992406
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4655,
    "percentage": 56.131677318220184
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.1808754371156397
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.44",
        "ok": "     2.43",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200587": {
        type: "REQUEST",
        name: "Rejection reason (citation 4)",
path: "Rejection reason (citation 4)",
pathFormatted: "req_rejection-reaso-933200587",
stats: {
    "name": "Rejection reason (citation 4)",
    "numberOfRequests": {
        "total": "    8,278",
        "ok": "    8,256",
        "ko": "       22"
    },
    "minResponseTime": {
        "total": "       31",
        "ok": "      271",
        "ko": "       31"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   46,411",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,027",
        "ok": "    6,006",
        "ko": "   14,132"
    },
    "standardDeviation": {
        "total": "    8,790",
        "ok": "    8,697",
        "ko": "   24,881"
    },
    "percentiles1": {
        "total": "    2,155",
        "ok": "    2,157",
        "ko": "      661"
    },
    "percentiles2": {
        "total": "    4,425",
        "ok": "    4,427",
        "ko": "    2,100"
    },
    "percentiles3": {
        "total": "   27,564",
        "ok": "   27,487",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   35,105",
        "ok": "   34,847",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 565,
    "percentage": 6.825320125634211
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 922,
    "percentage": 11.137956028026093
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6769,
    "percentage": 81.77095916888138
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 22,
    "percentage": 0.2657646774583233
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.43",
        "ok": "     2.42",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826134": {
        type: "REQUEST",
        name: "Cancel vote (citation 4)",
path: "Cancel vote (citation 4)",
pathFormatted: "req_cancel-vote--ci-1326826134",
stats: {
    "name": "Cancel vote (citation 4)",
    "numberOfRequests": {
        "total": "    8,256",
        "ok": "    8,238",
        "ko": "       18"
    },
    "minResponseTime": {
        "total": "        9",
        "ok": "      496",
        "ko": "        9"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   56,395",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    7,133",
        "ok": "    7,139",
        "ko": "    4,240"
    },
    "standardDeviation": {
        "total": "    9,788",
        "ok": "    9,777",
        "ko": "   13,565"
    },
    "percentiles1": {
        "total": "    2,688",
        "ok": "    2,691",
        "ko": "      776"
    },
    "percentiles2": {
        "total": "    5,910",
        "ok": "    5,926",
        "ko": "    1,286"
    },
    "percentiles3": {
        "total": "   30,328",
        "ok": "   30,317",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   41,638",
        "ok": "   41,561",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 123,
    "percentage": 1.489825581395349
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 583,
    "percentage": 7.061531007751938
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7532,
    "percentage": 91.23062015503875
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 18,
    "percentage": 0.2180232558139535
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.42",
        "ok": "     2.42",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768716000": {
        type: "REQUEST",
        name: "Accept vote (citation # 5)",
path: "Accept vote (citation # 5)",
pathFormatted: "req_accept-vote--ci--768716000",
stats: {
    "name": "Accept vote (citation # 5)",
    "numberOfRequests": {
        "total": "    8,238",
        "ok": "    8,222",
        "ko": "       16"
    },
    "minResponseTime": {
        "total": "       11",
        "ok": "      530",
        "ko": "       11"
    },
    "maxResponseTime": {
        "total": "   49,559",
        "ok": "   49,559",
        "ko": "    4,109"
    },
    "meanResponseTime": {
        "total": "    7,287",
        "ok": "    7,299",
        "ko": "    1,039"
    },
    "standardDeviation": {
        "total": "    9,668",
        "ok": "    9,673",
        "ko": "    1,136"
    },
    "percentiles1": {
        "total": "    2,729",
        "ok": "    2,732",
        "ko": "      742"
    },
    "percentiles2": {
        "total": "    6,163",
        "ok": "    6,185",
        "ko": "    1,686"
    },
    "percentiles3": {
        "total": "   30,517",
        "ok": "   30,527",
        "ko": "    4,109"
    },
    "percentiles4": {
        "total": "   37,506",
        "ok": "   37,522",
        "ko": "    4,109"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 111,
    "percentage": 1.347414420975965
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 532,
    "percentage": 6.457878125758679
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7579,
    "percentage": 92.0004855547463
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16,
    "percentage": 0.19422189851905802
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.42",
        "ok": "     2.41",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826165": {
        type: "REQUEST",
        name: "Cancel vote (citation 5)",
path: "Cancel vote (citation 5)",
pathFormatted: "req_cancel-vote--ci-1326826165",
stats: {
    "name": "Cancel vote (citation 5)",
    "numberOfRequests": {
        "total": "    8,222",
        "ok": "    8,215",
        "ko": "        7"
    },
    "minResponseTime": {
        "total": "       22",
        "ok": "      532",
        "ko": "       22"
    },
    "maxResponseTime": {
        "total": "   55,952",
        "ok": "   55,952",
        "ko": "    1,735"
    },
    "meanResponseTime": {
        "total": "    7,389",
        "ok": "    7,395",
        "ko": "      584"
    },
    "standardDeviation": {
        "total": "   10,073",
        "ok": "   10,076",
        "ko": "      657"
    },
    "percentiles1": {
        "total": "    2,741",
        "ok": "    2,743",
        "ko": "      102"
    },
    "percentiles2": {
        "total": "    6,186",
        "ok": "    6,196",
        "ko": "    1,395"
    },
    "percentiles3": {
        "total": "   31,061",
        "ok": "   31,068",
        "ko": "    1,735"
    },
    "percentiles4": {
        "total": "   43,039",
        "ok": "   43,041",
        "ko": "    1,735"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 91,
    "percentage": 1.1067866699099975
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 546,
    "percentage": 6.640720019459985
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7578,
    "percentage": 92.16735587448309
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 7,
    "percentage": 0.08513743614692289
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.41",
        "ok": "     2.41",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768715969": {
        type: "REQUEST",
        name: "Accept vote (citation # 6)",
path: "Accept vote (citation # 6)",
pathFormatted: "req_accept-vote--ci--768715969",
stats: {
    "name": "Accept vote (citation # 6)",
    "numberOfRequests": {
        "total": "    8,215",
        "ok": "    8,195",
        "ko": "       20"
    },
    "minResponseTime": {
        "total": "       25",
        "ok": "      547",
        "ko": "       25"
    },
    "maxResponseTime": {
        "total": "   50,123",
        "ok": "   50,123",
        "ko": "    8,003"
    },
    "meanResponseTime": {
        "total": "    7,230",
        "ok": "    7,245",
        "ko": "    1,136"
    },
    "standardDeviation": {
        "total": "    9,654",
        "ok": "    9,661",
        "ko": "    1,807"
    },
    "percentiles1": {
        "total": "    2,801",
        "ok": "    2,807",
        "ko": "      532"
    },
    "percentiles2": {
        "total": "    6,093",
        "ok": "    6,112",
        "ko": "    1,173"
    },
    "percentiles3": {
        "total": "   30,975",
        "ok": "   30,991",
        "ko": "    8,003"
    },
    "percentiles4": {
        "total": "   39,221",
        "ok": "   39,233",
        "ko": "    8,003"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 79,
    "percentage": 0.9616555082166769
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 474,
    "percentage": 5.769933049300061
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7642,
    "percentage": 93.0249543517955
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 20,
    "percentage": 0.24345709068776628
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.41",
        "ok": "     2.41",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826196": {
        type: "REQUEST",
        name: "Cancel vote (citation 6)",
path: "Cancel vote (citation 6)",
pathFormatted: "req_cancel-vote--ci-1326826196",
stats: {
    "name": "Cancel vote (citation 6)",
    "numberOfRequests": {
        "total": "    8,195",
        "ok": "    8,183",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       41",
        "ok": "      553",
        "ko": "       41"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   56,380",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    7,426",
        "ok": "    7,428",
        "ko": "    6,060"
    },
    "standardDeviation": {
        "total": "   10,037",
        "ok": "   10,025",
        "ko": "   16,292"
    },
    "percentiles1": {
        "total": "    2,842",
        "ok": "    2,845",
        "ko": "    1,322"
    },
    "percentiles2": {
        "total": "    6,172",
        "ok": "    6,180",
        "ko": "    2,700"
    },
    "percentiles3": {
        "total": "   31,158",
        "ok": "   31,149",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   42,006",
        "ok": "   41,936",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 80,
    "percentage": 0.9762050030506406
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 443,
    "percentage": 5.405735204392922
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7660,
    "percentage": 93.47162904209884
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.1464307504575961
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.41",
        "ok": "      2.4",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155050101": {
        type: "REQUEST",
        name: "Reject vote (citation # 7)",
path: "Reject vote (citation # 7)",
pathFormatted: "req_reject-vote--ci-155050101",
stats: {
    "name": "Reject vote (citation # 7)",
    "numberOfRequests": {
        "total": "    8,183",
        "ok": "    8,170",
        "ko": "       13"
    },
    "minResponseTime": {
        "total": "       10",
        "ok": "      464",
        "ko": "       10"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   46,741",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    6,163",
        "ok": "    6,164",
        "ko": "    5,713"
    },
    "standardDeviation": {
        "total": "    9,590",
        "ok": "    9,577",
        "ko": "   15,700"
    },
    "percentiles1": {
        "total": "    1,437",
        "ok": "    1,438",
        "ko": "    1,213"
    },
    "percentiles2": {
        "total": "    5,059",
        "ok": "    5,073",
        "ko": "    1,911"
    },
    "percentiles3": {
        "total": "   29,341",
        "ok": "   29,359",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   36,718",
        "ok": "   36,639",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1847,
    "percentage": 22.57118416228767
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1673,
    "percentage": 20.444824636441403
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4650,
    "percentage": 56.82512525968472
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 13,
    "percentage": 0.1588659415862153
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      2.4",
        "ok": "      2.4",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200680": {
        type: "REQUEST",
        name: "Rejection reason (citation 7)",
path: "Rejection reason (citation 7)",
pathFormatted: "req_rejection-reaso-933200680",
stats: {
    "name": "Rejection reason (citation 7)",
    "numberOfRequests": {
        "total": "    8,170",
        "ok": "    8,158",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       21",
        "ok": "      299",
        "ko": "       21"
    },
    "maxResponseTime": {
        "total": "   46,217",
        "ok": "   46,217",
        "ko": "    2,572"
    },
    "meanResponseTime": {
        "total": "    6,033",
        "ok": "    6,040",
        "ko": "      846"
    },
    "standardDeviation": {
        "total": "    8,700",
        "ok": "    8,704",
        "ko": "      964"
    },
    "percentiles1": {
        "total": "    2,140",
        "ok": "    2,142",
        "ko": "      453"
    },
    "percentiles2": {
        "total": "    4,448",
        "ok": "    4,461",
        "ko": "    1,947"
    },
    "percentiles3": {
        "total": "   27,549",
        "ok": "   27,558",
        "ko": "    2,572"
    },
    "percentiles4": {
        "total": "   33,976",
        "ok": "   33,980",
        "ko": "    2,572"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 584,
    "percentage": 7.148102815177479
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 922,
    "percentage": 11.285189718482252
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6652,
    "percentage": 81.41982864137087
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.14687882496940025
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      2.4",
        "ok": "      2.4",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826227": {
        type: "REQUEST",
        name: "Cancel vote (citation 7)",
path: "Cancel vote (citation 7)",
pathFormatted: "req_cancel-vote--ci-1326826227",
stats: {
    "name": "Cancel vote (citation 7)",
    "numberOfRequests": {
        "total": "    8,158",
        "ok": "    8,142",
        "ko": "       16"
    },
    "minResponseTime": {
        "total": "       37",
        "ok": "      571",
        "ko": "       37"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   55,983",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    7,387",
        "ok": "    7,393",
        "ko": "    4,522"
    },
    "standardDeviation": {
        "total": "    9,968",
        "ok": "    9,957",
        "ko": "   14,351"
    },
    "percentiles1": {
        "total": "    2,838",
        "ok": "    2,842",
        "ko": "      649"
    },
    "percentiles2": {
        "total": "    6,128",
        "ok": "    6,142",
        "ko": "    1,454"
    },
    "percentiles3": {
        "total": "   31,005",
        "ok": "   31,002",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   41,190",
        "ok": "   41,131",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 68,
    "percentage": 0.8335376317724933
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 438,
    "percentage": 5.368962981122824
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7636,
    "percentage": 93.60137288551115
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 16,
    "percentage": 0.19612650159352782
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      2.4",
        "ok": "     2.39",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155050132": {
        type: "REQUEST",
        name: "Reject vote (citation # 8)",
path: "Reject vote (citation # 8)",
pathFormatted: "req_reject-vote--ci-155050132",
stats: {
    "name": "Reject vote (citation # 8)",
    "numberOfRequests": {
        "total": "    8,142",
        "ok": "    8,131",
        "ko": "       11"
    },
    "minResponseTime": {
        "total": "       21",
        "ok": "      462",
        "ko": "       21"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   47,250",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    5,793",
        "ok": "    5,785",
        "ko": "   11,511"
    },
    "standardDeviation": {
        "total": "    9,245",
        "ok": "    9,211",
        "ko": "   22,866"
    },
    "percentiles1": {
        "total": "    1,408",
        "ok": "    1,409",
        "ko": "      714"
    },
    "percentiles2": {
        "total": "    4,367",
        "ok": "    4,370",
        "ko": "    1,989"
    },
    "percentiles3": {
        "total": "   28,853",
        "ok": "   28,815",
        "ko": "   60,000"
    },
    "percentiles4": {
        "total": "   35,979",
        "ok": "   35,825",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 1925,
    "percentage": 23.642839597150576
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1609,
    "percentage": 19.761729304839108
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 4597,
    "percentage": 56.46032915745517
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0.13510194055514615
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.39",
        "ok": "     2.39",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200711": {
        type: "REQUEST",
        name: "Rejection reason (citation 8)",
path: "Rejection reason (citation 8)",
pathFormatted: "req_rejection-reaso-933200711",
stats: {
    "name": "Rejection reason (citation 8)",
    "numberOfRequests": {
        "total": "    8,131",
        "ok": "    8,119",
        "ko": "       12"
    },
    "minResponseTime": {
        "total": "       28",
        "ok": "      298",
        "ko": "       28"
    },
    "maxResponseTime": {
        "total": "   47,492",
        "ok": "   47,492",
        "ko": "    3,596"
    },
    "meanResponseTime": {
        "total": "    5,910",
        "ok": "    5,918",
        "ko": "      872"
    },
    "standardDeviation": {
        "total": "    8,490",
        "ok": "    8,494",
        "ko": "    1,162"
    },
    "percentiles1": {
        "total": "    2,136",
        "ok": "    2,138",
        "ko": "      312"
    },
    "percentiles2": {
        "total": "    4,455",
        "ok": "    4,468",
        "ko": "    1,103"
    },
    "percentiles3": {
        "total": "   26,681",
        "ok": "   26,688",
        "ko": "    3,596"
    },
    "percentiles4": {
        "total": "   33,770",
        "ok": "   33,775",
        "ko": "    3,596"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 595,
    "percentage": 7.317673102939367
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 891,
    "percentage": 10.95806173902349
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 6633,
    "percentage": 81.57668183495265
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 12,
    "percentage": 0.14758332308449146
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.39",
        "ok": "     2.38",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826258": {
        type: "REQUEST",
        name: "Cancel vote (citation 8)",
path: "Cancel vote (citation 8)",
pathFormatted: "req_cancel-vote--ci-1326826258",
stats: {
    "name": "Cancel vote (citation 8)",
    "numberOfRequests": {
        "total": "    8,119",
        "ok": "    8,096",
        "ko": "       23"
    },
    "minResponseTime": {
        "total": "       32",
        "ok": "      542",
        "ko": "       32"
    },
    "maxResponseTime": {
        "total": "   60,000",
        "ok": "   58,589",
        "ko": "   60,000"
    },
    "meanResponseTime": {
        "total": "    7,784",
        "ok": "    7,796",
        "ko": "    3,534"
    },
    "standardDeviation": {
        "total": "   10,400",
        "ok": "   10,392",
        "ko": "   12,104"
    },
    "percentiles1": {
        "total": "    2,911",
        "ok": "    2,916",
        "ko": "      473"
    },
    "percentiles2": {
        "total": "    6,559",
        "ok": "    6,585",
        "ko": "      968"
    },
    "percentiles3": {
        "total": "   32,071",
        "ok": "   32,042",
        "ko": "    4,154"
    },
    "percentiles4": {
        "total": "   42,787",
        "ok": "   42,729",
        "ko": "   60,000"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 39,
    "percentage": 0.4803547234881143
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 374,
    "percentage": 4.606478630373199
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 7683,
    "percentage": 94.62988052715852
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 23,
    "percentage": 0.28328611898017
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     2.38",
        "ok": "     2.38",
        "ko": "     0.01"
    }
}
    },"req_go-to-user-prog-1344154810": {
        type: "REQUEST",
        name: "Go to user program page Redirect 1",
path: "Go to user program page Redirect 1",
pathFormatted: "req_go-to-user-prog-1344154810",
stats: {
    "name": "Go to user program page Redirect 1",
    "numberOfRequests": {
        "total": "      150",
        "ok": "        0",
        "ko": "      150"
    },
    "minResponseTime": {
        "total": "      169",
        "ok": "        -",
        "ko": "      169"
    },
    "maxResponseTime": {
        "total": "   14,482",
        "ok": "        -",
        "ko": "   14,482"
    },
    "meanResponseTime": {
        "total": "    1,035",
        "ok": "        -",
        "ko": "    1,035"
    },
    "standardDeviation": {
        "total": "    1,938",
        "ok": "        -",
        "ko": "    1,938"
    },
    "percentiles1": {
        "total": "      443",
        "ok": "        -",
        "ko": "      443"
    },
    "percentiles2": {
        "total": "      825",
        "ok": "        -",
        "ko": "      825"
    },
    "percentiles3": {
        "total": "    6,107",
        "ok": "        -",
        "ko": "    6,107"
    },
    "percentiles4": {
        "total": "    9,112",
        "ok": "        -",
        "ko": "    9,112"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 150,
    "percentage": 100.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.04",
        "ok": "        -",
        "ko": "     0.04"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
