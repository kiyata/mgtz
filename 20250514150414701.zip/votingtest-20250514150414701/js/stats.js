var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name--1146707516",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "  215,338",
        "ok": "  215,088",
        "ko": "      250"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "       15"
    },
    "maxResponseTime": {
        "total": "   30,395",
        "ok": "   30,395",
        "ko": "    3,407"
    },
    "meanResponseTime": {
        "total": "    4,588",
        "ok": "    4,593",
        "ko": "      441"
    },
    "standardDeviation": {
        "total": "    3,270",
        "ok": "    3,269",
        "ko": "      505"
    },
    "percentiles1": {
        "total": "    3,654",
        "ok": "    3,659",
        "ko": "      248"
    },
    "percentiles2": {
        "total": "    6,032",
        "ok": "    6,037",
        "ko": "      577"
    },
    "percentiles3": {
        "total": "   11,055",
        "ok": "   11,074",
        "ko": "    1,491"
    },
    "percentiles4": {
        "total": "   16,252",
        "ok": "   16,273",
        "ko": "    2,210"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3661,
    "percentage": 1.700117954100066
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 9452,
    "percentage": 4.389378558359416
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 201975,
    "percentage": 93.7944069323575
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 250,
    "percentage": 0.11609655518301462
},
    "meanNumberOfRequestsPerSecond": {
        "total": "    74.56",
        "ok": "    74.48",
        "ko": "     0.09"
    }
},
contents: {
"req_go-to-login-pag-1537763987": {
        type: "REQUEST",
        name: "Go to login page",
path: "Go to login page",
pathFormatted: "req_go-to-login-pag-1537763987",
stats: {
    "name": "Go to login page",
    "numberOfRequests": {
        "total": "      852",
        "ok": "      852",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "        2",
        "ok": "        2",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "    1,050",
        "ok": "    1,050",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "        5",
        "ok": "        5",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "       36",
        "ok": "       36",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "        3",
        "ok": "        3",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "        4",
        "ok": "        4",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "        7",
        "ok": "        7",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 851,
    "percentage": 99.88262910798123
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1,
    "percentage": 0.11737089201877934
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 0,
    "percentage": 0.0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      0.3",
        "ok": "      0.3",
        "ko": "        -"
    }
}
    },"req_submit-credenti--2043499788": {
        type: "REQUEST",
        name: "submit credentials",
path: "submit credentials",
pathFormatted: "req_submit-credenti--2043499788",
stats: {
    "name": "submit credentials",
    "numberOfRequests": {
        "total": "      852",
        "ok": "      849",
        "ko": "        3"
    },
    "minResponseTime": {
        "total": "      176",
        "ok": "      276",
        "ko": "      176"
    },
    "maxResponseTime": {
        "total": "   17,111",
        "ok": "   17,111",
        "ko": "    1,078"
    },
    "meanResponseTime": {
        "total": "    2,443",
        "ok": "    2,450",
        "ko": "      554"
    },
    "standardDeviation": {
        "total": "    2,588",
        "ok": "    2,590",
        "ko": "      383"
    },
    "percentiles1": {
        "total": "    1,295",
        "ok": "    1,303",
        "ko": "      407"
    },
    "percentiles2": {
        "total": "    3,471",
        "ok": "    3,478",
        "ko": "    1,078"
    },
    "percentiles3": {
        "total": "    7,672",
        "ok": "    7,675",
        "ko": "    1,078"
    },
    "percentiles4": {
        "total": "   11,776",
        "ok": "   11,776",
        "ko": "    1,078"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 304,
    "percentage": 35.68075117370892
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 102,
    "percentage": 11.971830985915492
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 443,
    "percentage": 51.99530516431925
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 3,
    "percentage": 0.35211267605633806
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      0.3",
        "ok": "     0.29",
        "ko": "        0"
    }
}
    },"req_check-user-logg-946489478": {
        type: "REQUEST",
        name: "check user logged in",
path: "check user logged in",
pathFormatted: "req_check-user-logg-946489478",
stats: {
    "name": "check user logged in",
    "numberOfRequests": {
        "total": "      849",
        "ok": "      849",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "      533",
        "ok": "      533",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   17,172",
        "ok": "   17,172",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    3,170",
        "ok": "    3,170",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    2,834",
        "ok": "    2,834",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    2,189",
        "ok": "    2,189",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    4,278",
        "ok": "    4,278",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "    9,034",
        "ok": "    8,926",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   13,231",
        "ok": "   13,231",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 89,
    "percentage": 10.482921083627797
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 159,
    "percentage": 18.727915194346288
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 601,
    "percentage": 70.78916372202592
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.29",
        "ok": "     0.29",
        "ko": "        -"
    }
}
    },"req_go-to-user-prog--2104020333": {
        type: "REQUEST",
        name: "Go to user program page",
path: "Go to user program page",
pathFormatted: "req_go-to-user-prog--2104020333",
stats: {
    "name": "Go to user program page",
    "numberOfRequests": {
        "total": "      849",
        "ok": "      849",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "    1,044",
        "ok": "    1,044",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   22,372",
        "ok": "   22,372",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    5,754",
        "ok": "    5,754",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    3,623",
        "ok": "    3,623",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    4,857",
        "ok": "    4,857",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    7,290",
        "ok": "    7,290",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   12,929",
        "ok": "   12,929",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   18,915",
        "ok": "   18,915",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 3,
    "percentage": 0.35335689045936397
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 846,
    "percentage": 99.64664310954063
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     0.29",
        "ok": "     0.29",
        "ko": "        -"
    }
}
    },"req_go-to-breakout---1000037037": {
        type: "REQUEST",
        name: "Go to breakout page",
path: "Go to breakout page",
pathFormatted: "req_go-to-breakout---1000037037",
stats: {
    "name": "Go to breakout page",
    "numberOfRequests": {
        "total": "   10,209",
        "ok": "   10,209",
        "ko": "        0"
    },
    "minResponseTime": {
        "total": "      970",
        "ok": "      970",
        "ko": "        -"
    },
    "maxResponseTime": {
        "total": "   30,395",
        "ok": "   30,395",
        "ko": "        -"
    },
    "meanResponseTime": {
        "total": "    5,511",
        "ok": "    5,511",
        "ko": "        -"
    },
    "standardDeviation": {
        "total": "    3,803",
        "ok": "    3,803",
        "ko": "        -"
    },
    "percentiles1": {
        "total": "    4,543",
        "ok": "    4,543",
        "ko": "        -"
    },
    "percentiles2": {
        "total": "    7,203",
        "ok": "    7,203",
        "ko": "        -"
    },
    "percentiles3": {
        "total": "   13,018",
        "ok": "   13,018",
        "ko": "        -"
    },
    "percentiles4": {
        "total": "   18,818",
        "ok": "   18,818",
        "ko": "        -"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0.0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 45,
    "percentage": 0.44078754040552454
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 10164,
    "percentage": 99.55921245959448
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0.0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.53",
        "ok": "     3.53",
        "ko": "        -"
    }
}
    },"req_accept-vote--ci--768716124": {
        type: "REQUEST",
        name: "Accept vote (citation # 1)",
path: "Accept vote (citation # 1)",
pathFormatted: "req_accept-vote--ci--768716124",
stats: {
    "name": "Accept vote (citation # 1)",
    "numberOfRequests": {
        "total": "   10,209",
        "ok": "   10,195",
        "ko": "       14"
    },
    "minResponseTime": {
        "total": "       36",
        "ok": "      456",
        "ko": "       36"
    },
    "maxResponseTime": {
        "total": "   21,876",
        "ok": "   21,876",
        "ko": "    1,625"
    },
    "meanResponseTime": {
        "total": "    4,550",
        "ok": "    4,556",
        "ko": "      500"
    },
    "standardDeviation": {
        "total": "    2,960",
        "ok": "    2,958",
        "ko": "      472"
    },
    "percentiles1": {
        "total": "    3,681",
        "ok": "    3,686",
        "ko": "      272"
    },
    "percentiles2": {
        "total": "    5,894",
        "ok": "    5,898",
        "ko": "      958"
    },
    "percentiles3": {
        "total": "   10,463",
        "ok": "   10,463",
        "ko": "    1,625"
    },
    "percentiles4": {
        "total": "   14,629",
        "ok": "   14,666",
        "ko": "    1,625"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 36,
    "percentage": 0.35263003232441964
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 230,
    "percentage": 2.2529140954060143
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9929,
    "percentage": 97.25732197081007
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0.13713390145949653
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.53",
        "ok": "     3.53",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826041": {
        type: "REQUEST",
        name: "Cancel vote (citation 1)",
path: "Cancel vote (citation 1)",
pathFormatted: "req_cancel-vote--ci-1326826041",
stats: {
    "name": "Cancel vote (citation 1)",
    "numberOfRequests": {
        "total": "   10,195",
        "ok": "   10,184",
        "ko": "       11"
    },
    "minResponseTime": {
        "total": "       15",
        "ok": "      553",
        "ko": "       15"
    },
    "maxResponseTime": {
        "total": "   23,108",
        "ok": "   23,108",
        "ko": "      923"
    },
    "meanResponseTime": {
        "total": "    4,673",
        "ok": "    4,677",
        "ko": "      276"
    },
    "standardDeviation": {
        "total": "    3,180",
        "ok": "    3,179",
        "ko": "      278"
    },
    "percentiles1": {
        "total": "    3,695",
        "ok": "    3,699",
        "ko": "      175"
    },
    "percentiles2": {
        "total": "    5,990",
        "ok": "    5,993",
        "ko": "      407"
    },
    "percentiles3": {
        "total": "   10,827",
        "ok": "   10,830",
        "ko": "      923"
    },
    "percentiles4": {
        "total": "   16,585",
        "ok": "   16,589",
        "ko": "      923"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 26,
    "percentage": 0.25502697400686614
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 223,
    "percentage": 2.187346738597352
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9935,
    "percentage": 97.44973025993134
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0.10789602746444336
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.53",
        "ok": "     3.53",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768716093": {
        type: "REQUEST",
        name: "Accept vote (citation # 2)",
path: "Accept vote (citation # 2)",
pathFormatted: "req_accept-vote--ci--768716093",
stats: {
    "name": "Accept vote (citation # 2)",
    "numberOfRequests": {
        "total": "   10,184",
        "ok": "   10,170",
        "ko": "       14"
    },
    "minResponseTime": {
        "total": "       46",
        "ok": "      496",
        "ko": "       46"
    },
    "maxResponseTime": {
        "total": "   23,160",
        "ok": "   23,160",
        "ko": "    3,407"
    },
    "meanResponseTime": {
        "total": "    4,686",
        "ok": "    4,691",
        "ko": "      637"
    },
    "standardDeviation": {
        "total": "    3,103",
        "ok": "    3,102",
        "ko": "      914"
    },
    "percentiles1": {
        "total": "    3,767",
        "ok": "    3,772",
        "ko": "      335"
    },
    "percentiles2": {
        "total": "    6,088",
        "ok": "    6,092",
        "ko": "      589"
    },
    "percentiles3": {
        "total": "   11,068",
        "ok": "   11,071",
        "ko": "    3,407"
    },
    "percentiles4": {
        "total": "   15,404",
        "ok": "   15,407",
        "ko": "    3,407"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 0.1178318931657502
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 246,
    "percentage": 2.415553809897879
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9912,
    "percentage": 97.32914375490967
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0.13747054202670855
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.53",
        "ok": "     3.52",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826072": {
        type: "REQUEST",
        name: "Cancel vote (citation 2)",
path: "Cancel vote (citation 2)",
pathFormatted: "req_cancel-vote--ci-1326826072",
stats: {
    "name": "Cancel vote (citation 2)",
    "numberOfRequests": {
        "total": "   10,170",
        "ok": "   10,153",
        "ko": "       17"
    },
    "minResponseTime": {
        "total": "       38",
        "ok": "      623",
        "ko": "       38"
    },
    "maxResponseTime": {
        "total": "   23,631",
        "ok": "   23,631",
        "ko": "    2,274"
    },
    "meanResponseTime": {
        "total": "    4,730",
        "ok": "    4,737",
        "ko": "      553"
    },
    "standardDeviation": {
        "total": "    3,217",
        "ok": "    3,215",
        "ko": "      648"
    },
    "percentiles1": {
        "total": "    3,791",
        "ok": "    3,798",
        "ko": "      124"
    },
    "percentiles2": {
        "total": "    6,050",
        "ok": "    6,055",
        "ko": "      923"
    },
    "percentiles3": {
        "total": "   10,997",
        "ok": "   11,002",
        "ko": "    2,274"
    },
    "percentiles4": {
        "total": "   16,963",
        "ok": "   16,970",
        "ko": "    2,274"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 18,
    "percentage": 0.17699115044247787
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 201,
    "percentage": 1.9764011799410028
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9934,
    "percentage": 97.67944936086529
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17,
    "percentage": 0.16715830875122908
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.52",
        "ok": "     3.52",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155049977": {
        type: "REQUEST",
        name: "Reject vote (citation # 3)",
path: "Reject vote (citation # 3)",
pathFormatted: "req_reject-vote--ci-155049977",
stats: {
    "name": "Reject vote (citation # 3)",
    "numberOfRequests": {
        "total": "   10,153",
        "ok": "   10,147",
        "ko": "        6"
    },
    "minResponseTime": {
        "total": "      102",
        "ok": "      530",
        "ko": "      102"
    },
    "maxResponseTime": {
        "total": "   21,634",
        "ok": "   21,634",
        "ko": "      402"
    },
    "meanResponseTime": {
        "total": "    3,921",
        "ok": "    3,923",
        "ko": "      267"
    },
    "standardDeviation": {
        "total": "    3,201",
        "ok": "    3,201",
        "ko": "       99"
    },
    "percentiles1": {
        "total": "    2,963",
        "ok": "    2,965",
        "ko": "      310"
    },
    "percentiles2": {
        "total": "    5,351",
        "ok": "    5,353",
        "ko": "      333"
    },
    "percentiles3": {
        "total": "   10,434",
        "ok": "   10,435",
        "ko": "      402"
    },
    "percentiles4": {
        "total": "   15,179",
        "ok": "   15,180",
        "ko": "      402"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 424,
    "percentage": 4.176105584556289
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1336,
    "percentage": 13.15867231360189
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8387,
    "percentage": 82.6061262680981
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0.05909583374372107
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.52",
        "ok": "     3.51",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200556": {
        type: "REQUEST",
        name: "Rejection reason (citation 3)",
path: "Rejection reason (citation 3)",
pathFormatted: "req_rejection-reaso-933200556",
stats: {
    "name": "Rejection reason (citation 3)",
    "numberOfRequests": {
        "total": "   10,147",
        "ok": "   10,130",
        "ko": "       17"
    },
    "minResponseTime": {
        "total": "       17",
        "ok": "      339",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   20,550",
        "ok": "   20,550",
        "ko": "    1,241"
    },
    "meanResponseTime": {
        "total": "    4,084",
        "ok": "    4,090",
        "ko": "      242"
    },
    "standardDeviation": {
        "total": "    2,853",
        "ok": "    2,851",
        "ko": "      301"
    },
    "percentiles1": {
        "total": "    3,180",
        "ok": "    3,186",
        "ko": "       90"
    },
    "percentiles2": {
        "total": "    5,395",
        "ok": "    5,400",
        "ko": "      382"
    },
    "percentiles3": {
        "total": "    9,972",
        "ok": "    9,977",
        "ko": "    1,241"
    },
    "percentiles4": {
        "total": "   14,065",
        "ok": "   14,073",
        "ko": "    1,241"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 149,
    "percentage": 1.4684143096481719
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 498,
    "percentage": 4.907854538287179
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9483,
    "percentage": 93.45619394895043
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17,
    "percentage": 0.16753720311422096
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.51",
        "ok": "     3.51",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826103": {
        type: "REQUEST",
        name: "Cancel vote (citation 3)",
path: "Cancel vote (citation 3)",
pathFormatted: "req_cancel-vote--ci-1326826103",
stats: {
    "name": "Cancel vote (citation 3)",
    "numberOfRequests": {
        "total": "   10,130",
        "ok": "   10,119",
        "ko": "       11"
    },
    "minResponseTime": {
        "total": "       31",
        "ok": "      597",
        "ko": "       31"
    },
    "maxResponseTime": {
        "total": "   24,159",
        "ok": "   24,159",
        "ko": "      995"
    },
    "meanResponseTime": {
        "total": "    4,828",
        "ok": "    4,833",
        "ko": "      360"
    },
    "standardDeviation": {
        "total": "    3,294",
        "ok": "    3,293",
        "ko": "      271"
    },
    "percentiles1": {
        "total": "    3,875",
        "ok": "    3,879",
        "ko": "      263"
    },
    "percentiles2": {
        "total": "    6,146",
        "ok": "    6,150",
        "ko": "      530"
    },
    "percentiles3": {
        "total": "   11,217",
        "ok": "   11,220",
        "ko": "      995"
    },
    "percentiles4": {
        "total": "   17,470",
        "ok": "   17,474",
        "ko": "      995"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 14,
    "percentage": 0.13820335636722605
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 197,
    "percentage": 1.9447186574531095
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9908,
    "percentage": 97.80848963474827
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 11,
    "percentage": 0.10858835143139191
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.51",
        "ok": "      3.5",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155050008": {
        type: "REQUEST",
        name: "Reject vote (citation # 4)",
path: "Reject vote (citation # 4)",
pathFormatted: "req_reject-vote--ci-155050008",
stats: {
    "name": "Reject vote (citation # 4)",
    "numberOfRequests": {
        "total": "   10,119",
        "ok": "   10,104",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "       23",
        "ok": "      534",
        "ko": "       23"
    },
    "maxResponseTime": {
        "total": "   21,977",
        "ok": "   21,977",
        "ko": "    1,005"
    },
    "meanResponseTime": {
        "total": "    3,937",
        "ok": "    3,943",
        "ko": "      293"
    },
    "standardDeviation": {
        "total": "    3,248",
        "ok": "    3,247",
        "ko": "      269"
    },
    "percentiles1": {
        "total": "    2,967",
        "ok": "    2,973",
        "ko": "      179"
    },
    "percentiles2": {
        "total": "    5,390",
        "ok": "    5,395",
        "ko": "      443"
    },
    "percentiles3": {
        "total": "   10,550",
        "ok": "   10,556",
        "ko": "    1,005"
    },
    "percentiles4": {
        "total": "   15,462",
        "ok": "   15,467",
        "ko": "    1,005"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 392,
    "percentage": 3.8739005830615674
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1347,
    "percentage": 13.311592054550845
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8365,
    "percentage": 82.6662713706888
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.14823599169878449
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.5",
        "ok": "      3.5",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200587": {
        type: "REQUEST",
        name: "Rejection reason (citation 4)",
path: "Rejection reason (citation 4)",
pathFormatted: "req_rejection-reaso-933200587",
stats: {
    "name": "Rejection reason (citation 4)",
    "numberOfRequests": {
        "total": "   10,104",
        "ok": "   10,089",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "       39",
        "ok": "      344",
        "ko": "       39"
    },
    "maxResponseTime": {
        "total": "   21,251",
        "ok": "   21,251",
        "ko": "    1,428"
    },
    "meanResponseTime": {
        "total": "    4,093",
        "ok": "    4,098",
        "ko": "      312"
    },
    "standardDeviation": {
        "total": "    2,892",
        "ok": "    2,890",
        "ko": "      337"
    },
    "percentiles1": {
        "total": "    3,143",
        "ok": "    3,148",
        "ko": "      172"
    },
    "percentiles2": {
        "total": "    5,418",
        "ok": "    5,421",
        "ko": "      422"
    },
    "percentiles3": {
        "total": "    9,919",
        "ok": "    9,922",
        "ko": "    1,428"
    },
    "percentiles4": {
        "total": "   14,203",
        "ok": "   14,206",
        "ko": "    1,428"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 144,
    "percentage": 1.4251781472684086
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 503,
    "percentage": 4.978226444972289
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9442,
    "percentage": 93.44813935075219
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.14845605700712589
},
    "meanNumberOfRequestsPerSecond": {
        "total": "      3.5",
        "ok": "     3.49",
        "ko": "     0.01"
    }
}
    },"req_cancel-vote--ci-1326826134": {
        type: "REQUEST",
        name: "Cancel vote (citation 4)",
path: "Cancel vote (citation 4)",
pathFormatted: "req_cancel-vote--ci-1326826134",
stats: {
    "name": "Cancel vote (citation 4)",
    "numberOfRequests": {
        "total": "   10,089",
        "ok": "   10,075",
        "ko": "       14"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      538",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   23,717",
        "ok": "   23,717",
        "ko": "      940"
    },
    "meanResponseTime": {
        "total": "    4,925",
        "ok": "    4,931",
        "ko": "      323"
    },
    "standardDeviation": {
        "total": "    3,305",
        "ok": "    3,302",
        "ko": "      310"
    },
    "percentiles1": {
        "total": "    3,924",
        "ok": "    3,929",
        "ko": "      202"
    },
    "percentiles2": {
        "total": "    6,321",
        "ok": "    6,325",
        "ko": "      613"
    },
    "percentiles3": {
        "total": "   11,412",
        "ok": "   11,416",
        "ko": "      940"
    },
    "percentiles4": {
        "total": "   17,011",
        "ok": "   17,017",
        "ko": "      940"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 11,
    "percentage": 0.10902963623748638
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 154,
    "percentage": 1.5264149073248092
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9910,
    "percentage": 98.22579046486271
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0.13876499157498265
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.49",
        "ok": "     3.49",
        "ko": "        0"
    }
}
    },"req_accept-vote--ci--768716000": {
        type: "REQUEST",
        name: "Accept vote (citation # 5)",
path: "Accept vote (citation # 5)",
pathFormatted: "req_accept-vote--ci--768716000",
stats: {
    "name": "Accept vote (citation # 5)",
    "numberOfRequests": {
        "total": "   10,075",
        "ok": "   10,067",
        "ko": "        8"
    },
    "minResponseTime": {
        "total": "      201",
        "ok": "      624",
        "ko": "      201"
    },
    "maxResponseTime": {
        "total": "   24,315",
        "ok": "   24,315",
        "ko": "      878"
    },
    "meanResponseTime": {
        "total": "    4,976",
        "ok": "    4,980",
        "ko": "      528"
    },
    "standardDeviation": {
        "total": "    3,233",
        "ok": "    3,232",
        "ko": "      204"
    },
    "percentiles1": {
        "total": "    4,043",
        "ok": "    4,046",
        "ko": "      587"
    },
    "percentiles2": {
        "total": "    6,430",
        "ok": "    6,433",
        "ko": "      657"
    },
    "percentiles3": {
        "total": "   11,369",
        "ok": "   11,371",
        "ko": "      878"
    },
    "percentiles4": {
        "total": "   16,490",
        "ok": "   16,492",
        "ko": "      878"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 6,
    "percentage": 0.05955334987593052
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 150,
    "percentage": 1.488833746898263
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9911,
    "percentage": 98.37220843672456
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8,
    "percentage": 0.0794044665012407
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.49",
        "ok": "     3.49",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826165": {
        type: "REQUEST",
        name: "Cancel vote (citation 5)",
path: "Cancel vote (citation 5)",
pathFormatted: "req_cancel-vote--ci-1326826165",
stats: {
    "name": "Cancel vote (citation 5)",
    "numberOfRequests": {
        "total": "   10,067",
        "ok": "   10,050",
        "ko": "       17"
    },
    "minResponseTime": {
        "total": "       21",
        "ok": "      608",
        "ko": "       21"
    },
    "maxResponseTime": {
        "total": "   24,266",
        "ok": "   24,266",
        "ko": "    1,453"
    },
    "meanResponseTime": {
        "total": "    5,066",
        "ok": "    5,074",
        "ko": "      328"
    },
    "standardDeviation": {
        "total": "    3,352",
        "ok": "    3,349",
        "ko": "      396"
    },
    "percentiles1": {
        "total": "    4,091",
        "ok": "    4,098",
        "ko": "      169"
    },
    "percentiles2": {
        "total": "    6,509",
        "ok": "    6,514",
        "ko": "      322"
    },
    "percentiles3": {
        "total": "   11,563",
        "ok": "   11,569",
        "ko": "    1,453"
    },
    "percentiles4": {
        "total": "   17,535",
        "ok": "   17,538",
        "ko": "    1,453"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 13,
    "percentage": 0.12913479686103108
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 114,
    "percentage": 1.1324128340121187
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9923,
    "percentage": 98.56958378861627
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 17,
    "percentage": 0.16886858051057912
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.49",
        "ok": "     3.48",
        "ko": "     0.01"
    }
}
    },"req_accept-vote--ci--768715969": {
        type: "REQUEST",
        name: "Accept vote (citation # 6)",
path: "Accept vote (citation # 6)",
pathFormatted: "req_accept-vote--ci--768715969",
stats: {
    "name": "Accept vote (citation # 6)",
    "numberOfRequests": {
        "total": "   10,050",
        "ok": "   10,042",
        "ko": "        8"
    },
    "minResponseTime": {
        "total": "       19",
        "ok": "      724",
        "ko": "       19"
    },
    "maxResponseTime": {
        "total": "   23,526",
        "ok": "   23,526",
        "ko": "    1,491"
    },
    "meanResponseTime": {
        "total": "    5,099",
        "ok": "    5,103",
        "ko": "      446"
    },
    "standardDeviation": {
        "total": "    3,252",
        "ok": "    3,250",
        "ko": "      432"
    },
    "percentiles1": {
        "total": "    4,139",
        "ok": "    4,142",
        "ko": "      393"
    },
    "percentiles2": {
        "total": "    6,609",
        "ok": "    6,612",
        "ko": "      648"
    },
    "percentiles3": {
        "total": "   11,703",
        "ok": "   11,706",
        "ko": "    1,491"
    },
    "percentiles4": {
        "total": "   16,326",
        "ok": "   16,327",
        "ko": "    1,491"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 0.029850746268656716
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 87,
    "percentage": 0.8656716417910447
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9952,
    "percentage": 99.02487562189054
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8,
    "percentage": 0.07960199004975124
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.48",
        "ok": "     3.48",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826196": {
        type: "REQUEST",
        name: "Cancel vote (citation 6)",
path: "Cancel vote (citation 6)",
pathFormatted: "req_cancel-vote--ci-1326826196",
stats: {
    "name": "Cancel vote (citation 6)",
    "numberOfRequests": {
        "total": "   10,042",
        "ok": "   10,027",
        "ko": "       15"
    },
    "minResponseTime": {
        "total": "       44",
        "ok": "      625",
        "ko": "       44"
    },
    "maxResponseTime": {
        "total": "   24,169",
        "ok": "   24,169",
        "ko": "    2,210"
    },
    "meanResponseTime": {
        "total": "    5,191",
        "ok": "    5,198",
        "ko": "      565"
    },
    "standardDeviation": {
        "total": "    3,452",
        "ok": "    3,450",
        "ko": "      730"
    },
    "percentiles1": {
        "total": "    4,167",
        "ok": "    4,173",
        "ko": "      266"
    },
    "percentiles2": {
        "total": "    6,611",
        "ok": "    6,616",
        "ko": "      517"
    },
    "percentiles3": {
        "total": "   11,891",
        "ok": "   11,895",
        "ko": "    2,210"
    },
    "percentiles4": {
        "total": "   18,586",
        "ok": "   18,589",
        "ko": "    2,210"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 6,
    "percentage": 0.059749053973312094
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 100,
    "percentage": 0.9958175662218682
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9921,
    "percentage": 98.79506074487155
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 15,
    "percentage": 0.1493726349332802
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.48",
        "ok": "     3.47",
        "ko": "     0.01"
    }
}
    },"req_reject-vote--ci-155050101": {
        type: "REQUEST",
        name: "Reject vote (citation # 7)",
path: "Reject vote (citation # 7)",
pathFormatted: "req_reject-vote--ci-155050101",
stats: {
    "name": "Reject vote (citation # 7)",
    "numberOfRequests": {
        "total": "   10,027",
        "ok": "   10,018",
        "ko": "        9"
    },
    "minResponseTime": {
        "total": "       33",
        "ok": "      516",
        "ko": "       33"
    },
    "maxResponseTime": {
        "total": "   21,922",
        "ok": "   21,922",
        "ko": "    1,747"
    },
    "meanResponseTime": {
        "total": "    3,958",
        "ok": "    3,961",
        "ko": "      577"
    },
    "standardDeviation": {
        "total": "    3,204",
        "ok": "    3,204",
        "ko": "      593"
    },
    "percentiles1": {
        "total": "    3,052",
        "ok": "    3,056",
        "ko": "      445"
    },
    "percentiles2": {
        "total": "    5,333",
        "ok": "    5,336",
        "ko": "      636"
    },
    "percentiles3": {
        "total": "   10,550",
        "ok": "   10,569",
        "ko": "    1,747"
    },
    "percentiles4": {
        "total": "   15,071",
        "ok": "   15,070",
        "ko": "    1,747"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 419,
    "percentage": 4.1787174628503045
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1290,
    "percentage": 12.865263787773012
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8309,
    "percentage": 82.86626109504338
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 9,
    "percentage": 0.08975765433330009
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.47",
        "ok": "     3.47",
        "ko": "        0"
    }
}
    },"req_rejection-reaso-933200680": {
        type: "REQUEST",
        name: "Rejection reason (citation 7)",
path: "Rejection reason (citation 7)",
pathFormatted: "req_rejection-reaso-933200680",
stats: {
    "name": "Rejection reason (citation 7)",
    "numberOfRequests": {
        "total": "   10,018",
        "ok": "   10,004",
        "ko": "       14"
    },
    "minResponseTime": {
        "total": "       17",
        "ok": "      394",
        "ko": "       17"
    },
    "maxResponseTime": {
        "total": "   20,699",
        "ok": "   20,699",
        "ko": "    1,106"
    },
    "meanResponseTime": {
        "total": "    4,076",
        "ok": "    4,082",
        "ko": "      414"
    },
    "standardDeviation": {
        "total": "    2,907",
        "ok": "    2,906",
        "ko": "      402"
    },
    "percentiles1": {
        "total": "    3,120",
        "ok": "    3,125",
        "ko": "      259"
    },
    "percentiles2": {
        "total": "    5,344",
        "ok": "    5,348",
        "ko": "      822"
    },
    "percentiles3": {
        "total": "   10,011",
        "ok": "   10,015",
        "ko": "    1,106"
    },
    "percentiles4": {
        "total": "   14,286",
        "ok": "   14,289",
        "ko": "    1,106"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 160,
    "percentage": 1.597125174685566
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 524,
    "percentage": 5.230584947095228
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9320,
    "percentage": 93.03254142543422
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 14,
    "percentage": 0.13974845278498702
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.47",
        "ok": "     3.46",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826227": {
        type: "REQUEST",
        name: "Cancel vote (citation 7)",
path: "Cancel vote (citation 7)",
pathFormatted: "req_cancel-vote--ci-1326826227",
stats: {
    "name": "Cancel vote (citation 7)",
    "numberOfRequests": {
        "total": "   10,004",
        "ok": "    9,996",
        "ko": "        8"
    },
    "minResponseTime": {
        "total": "       77",
        "ok": "      675",
        "ko": "       77"
    },
    "maxResponseTime": {
        "total": "   24,016",
        "ok": "   24,016",
        "ko": "      962"
    },
    "meanResponseTime": {
        "total": "    5,219",
        "ok": "    5,222",
        "ko": "      353"
    },
    "standardDeviation": {
        "total": "    3,419",
        "ok": "    3,417",
        "ko": "      298"
    },
    "percentiles1": {
        "total": "    4,247",
        "ok": "    4,250",
        "ko": "      348"
    },
    "percentiles2": {
        "total": "    6,676",
        "ok": "    6,678",
        "ko": "      644"
    },
    "percentiles3": {
        "total": "   11,808",
        "ok": "   11,811",
        "ko": "      962"
    },
    "percentiles4": {
        "total": "   18,382",
        "ok": "   18,385",
        "ko": "      962"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 5,
    "percentage": 0.04998000799680128
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 74,
    "percentage": 0.7397041183526589
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9917,
    "percentage": 99.13034786085566
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 8,
    "percentage": 0.07996801279488205
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.46",
        "ok": "     3.46",
        "ko": "        0"
    }
}
    },"req_reject-vote--ci-155050132": {
        type: "REQUEST",
        name: "Reject vote (citation # 8)",
path: "Reject vote (citation # 8)",
pathFormatted: "req_reject-vote--ci-155050132",
stats: {
    "name": "Reject vote (citation # 8)",
    "numberOfRequests": {
        "total": "    9,996",
        "ok": "    9,977",
        "ko": "       19"
    },
    "minResponseTime": {
        "total": "       24",
        "ok": "      524",
        "ko": "       24"
    },
    "maxResponseTime": {
        "total": "   21,529",
        "ok": "   21,529",
        "ko": "    2,143"
    },
    "meanResponseTime": {
        "total": "    3,962",
        "ok": "    3,968",
        "ko": "      726"
    },
    "standardDeviation": {
        "total": "    3,237",
        "ok": "    3,237",
        "ko": "      554"
    },
    "percentiles1": {
        "total": "    2,999",
        "ok": "    3,007",
        "ko": "      611"
    },
    "percentiles2": {
        "total": "    5,426",
        "ok": "    5,432",
        "ko": "    1,119"
    },
    "percentiles3": {
        "total": "   10,654",
        "ok": "   10,672",
        "ko": "    2,143"
    },
    "percentiles4": {
        "total": "   15,412",
        "ok": "   15,416",
        "ko": "    2,143"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 411,
    "percentage": 4.111644657863145
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 1280,
    "percentage": 12.805122048819529
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 8286,
    "percentage": 82.89315726290516
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 19,
    "percentage": 0.19007603041216486
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.46",
        "ok": "     3.45",
        "ko": "     0.01"
    }
}
    },"req_rejection-reaso-933200711": {
        type: "REQUEST",
        name: "Rejection reason (citation 8)",
path: "Rejection reason (citation 8)",
pathFormatted: "req_rejection-reaso-933200711",
stats: {
    "name": "Rejection reason (citation 8)",
    "numberOfRequests": {
        "total": "    9,977",
        "ok": "    9,971",
        "ko": "        6"
    },
    "minResponseTime": {
        "total": "       68",
        "ok": "      326",
        "ko": "       68"
    },
    "maxResponseTime": {
        "total": "   21,030",
        "ok": "   21,030",
        "ko": "    1,535"
    },
    "meanResponseTime": {
        "total": "    4,130",
        "ok": "    4,132",
        "ko": "      616"
    },
    "standardDeviation": {
        "total": "    2,934",
        "ok": "    2,934",
        "ko": "      628"
    },
    "percentiles1": {
        "total": "    3,206",
        "ok": "    3,208",
        "ko": "      473"
    },
    "percentiles2": {
        "total": "    5,354",
        "ok": "    5,356",
        "ko": "    1,427"
    },
    "percentiles3": {
        "total": "   10,155",
        "ok": "   10,156",
        "ko": "    1,535"
    },
    "percentiles4": {
        "total": "   14,338",
        "ok": "   14,339",
        "ko": "    1,535"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 165,
    "percentage": 1.6538037486218304
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 519,
    "percentage": 5.201964518392303
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9287,
    "percentage": 93.08409341485417
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 6,
    "percentage": 0.060138318131702916
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.45",
        "ok": "     3.45",
        "ko": "        0"
    }
}
    },"req_cancel-vote--ci-1326826258": {
        type: "REQUEST",
        name: "Cancel vote (citation 8)",
path: "Cancel vote (citation 8)",
pathFormatted: "req_cancel-vote--ci-1326826258",
stats: {
    "name": "Cancel vote (citation 8)",
    "numberOfRequests": {
        "total": "    9,971",
        "ok": "    9,962",
        "ko": "        9"
    },
    "minResponseTime": {
        "total": "       49",
        "ok": "      692",
        "ko": "       49"
    },
    "maxResponseTime": {
        "total": "   24,975",
        "ok": "   24,975",
        "ko": "    1,572"
    },
    "meanResponseTime": {
        "total": "    5,319",
        "ok": "    5,323",
        "ko": "      418"
    },
    "standardDeviation": {
        "total": "    3,415",
        "ok": "    3,414",
        "ko": "      458"
    },
    "percentiles1": {
        "total": "    4,380",
        "ok": "    4,383",
        "ko": "      339"
    },
    "percentiles2": {
        "total": "    6,791",
        "ok": "    6,793",
        "ko": "      592"
    },
    "percentiles3": {
        "total": "   11,816",
        "ok": "   11,818",
        "ko": "    1,572"
    },
    "percentiles4": {
        "total": "   18,122",
        "ok": "   18,125",
        "ko": "    1,572"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 0.03008725303379801
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t >= 800 ms <br> t < 1200 ms",
    "count": 69,
    "percentage": 0.6920068197773543
},
    "group3": {
    "name": "t >= 1200 ms",
    "htmlName": "t >= 1200 ms",
    "count": 9890,
    "percentage": 99.18764416808744
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 9,
    "percentage": 0.09026175910139404
},
    "meanNumberOfRequestsPerSecond": {
        "total": "     3.45",
        "ok": "     3.45",
        "ko": "        0"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
